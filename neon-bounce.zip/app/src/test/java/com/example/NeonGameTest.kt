package com.example

import com.example.engine.NeonPhysicsEngine
import com.example.engine.RunPhase
import com.example.localization.Localization
import com.example.model.AppLanguage
import com.example.model.GameCatalog
import com.example.model.GameMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NeonGameTest {

    @Test
    fun `catalog has 50 calibrated levels and power of 2 milestones up to 8192`() {
        assertEquals(50, GameCatalog.levels.size)
        assertEquals(1, GameCatalog.milestoneSequence.first())
        assertEquals(8192, GameCatalog.milestoneSequence.last())
        assertEquals(
            listOf(1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192),
            GameCatalog.milestoneSequence
        )
    }

    @Test
    fun `all three languages provide complete non-empty localized labels`() {
        AppLanguage.entries.forEach { lang ->
            val s = Localization.forLanguage(lang)
            assertEquals("NEON BOUNCE", s.appTitle)
            assertEquals("KHOLID COMPANY", s.developer)
            assertTrue(s.play.isNotBlank())
            assertTrue(s.music.isNotBlank())
            assertTrue(s.settings.isNotBlank())
            assertTrue(s.tapToLaunch.isNotBlank())
            assertTrue(s.levelComplete.isNotBlank())
        }
    }

    @Test
    fun `auto mode physics keeps ball alive and advances power of 2 milestones`() {
        val engine = NeonPhysicsEngine()
        engine.startNewGame(GameMode.CLASSIC, bestScore = 0, keepAuto = true)
        engine.launchIfReady()
        assertEquals(RunPhase.PLAYING, engine.phase)

        // Simulate 15 seconds of 60fps gameplay
        repeat(900) {
            engine.step(1f / 60f)
        }

        val snap = engine.snapshot()
        assertEquals(RunPhase.PLAYING, snap.phase)
        assertTrue("Expected bounces > 0, got ${snap.bounces}", snap.bounces > 0)
        assertTrue("Expected milestone >= 2, got ${snap.scoreMilestone}", snap.scoreMilestone >= 2)
    }

    @Test
    fun `manual swipe and drag gestures steer ball and catcher wave`() {
        val engine = NeonPhysicsEngine()
        engine.startNewGame(GameMode.ENDLESS, bestScore = 8, keepAuto = false)
        assertEquals(RunPhase.READY, engine.phase)

        engine.onTap(0.5f, 0.5f)
        assertEquals(RunPhase.PLAYING, engine.phase)

        engine.onDrag(0.75f, 0.80f, active = true)
        repeat(20) { engine.step(1f / 60f) }
        assertTrue("Catcher should move right toward 0.75, got ${engine.catcherX}", engine.catcherX > 0.6f)

        val vxBefore = engine.ballVx
        engine.onSwipe(-0.4f, 0.1f, 0.5f, 0.5f)
        assertTrue("Swipe should alter horizontal velocity", engine.ballVx != vxBefore)
    }

    @Test
    fun `level 1 completes cleanly when target milestone and bounces are reached`() {
        val engine = NeonPhysicsEngine()
        val level1 = GameCatalog.levels.first()
        engine.startNewGame(GameMode.LEVELS, bestScore = level1.targetMilestone, level = level1, keepAuto = true)
        engine.launchIfReady()

        repeat(3600) {
            if (engine.phase == RunPhase.LEVEL_COMPLETE) return@repeat
            engine.step(1f / 60f)
        }

        val snap = engine.snapshot()
        assertEquals(RunPhase.LEVEL_COMPLETE, snap.phase)
        assertTrue(snap.starsEarned in 1..3)
        assertTrue(snap.earnedShards >= level1.rewardShards)
    }
}
