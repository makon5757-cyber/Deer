package com.example.view

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.RectF
import android.util.AttributeSet
import android.view.Choreographer
import android.view.MotionEvent
import android.view.View
import com.example.engine.HudSnapshot
import com.example.engine.NeonPhysicsEngine
import com.example.engine.NeonRenderer
import com.example.engine.RunPhase
import com.example.model.ArenaTheme
import com.example.model.BallSkin
import com.example.model.GameCatalog
import com.example.model.GraphicsQuality
import com.example.model.TargetFps
import com.example.model.TrailSkin
import kotlin.math.hypot

class NeonArenaView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs), Choreographer.FrameCallback {

    val engine = NeonPhysicsEngine()
    private val renderer = NeonRenderer()
    private val arenaBounds = RectF(0f, 0f, 1f, 1f)

    private var ballSkin: BallSkin = GameCatalog.ballSkins.first()
    private var trailSkin: TrailSkin = GameCatalog.trailSkins.first()
    private var arenaTheme: ArenaTheme = GameCatalog.arenaThemes.first()
    private var quality: GraphicsQuality = GraphicsQuality.HIGH
    private var targetFps: TargetFps = TargetFps.FPS_60

    private var isLoopRunning = false
    private var lastFrameNanos = 0L
    private var accumulatedNanos = 0L
    private var hudUpdateAccumulator = 0f

    var onHudUpdate: ((HudSnapshot) -> Unit)? = null

    // Touch gesture tracking
    private var downX = 0f
    private var downY = 0f
    private var downTimeMs = 0L
    private var lastMoveX = 0f
    private var lastMoveY = 0f
    private var swipeTriggered = false

    init {
        setLayerType(LAYER_TYPE_HARDWARE, null)
        isClickable = true
        isFocusable = true
    }

    fun applyVisualConfig(
        ball: BallSkin,
        trail: TrailSkin,
        theme: ArenaTheme,
        graphicsQuality: GraphicsQuality,
        fps: TargetFps
    ) {
        ballSkin = ball
        trailSkin = trail
        arenaTheme = theme
        quality = graphicsQuality
        targetFps = fps
        renderer.configureQuality(graphicsQuality)
        engine.setPalette(theme.palette)
    }

    fun startLoop() {
        if (isLoopRunning) return
        isLoopRunning = true
        lastFrameNanos = 0L
        accumulatedNanos = 0L
        Choreographer.getInstance().postFrameCallback(this)
    }

    fun stopLoop() {
        isLoopRunning = false
        Choreographer.getInstance().removeFrameCallback(this)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startLoop()
    }

    override fun onDetachedFromWindow() {
        stopLoop()
        super.onDetachedFromWindow()
    }

    override fun doFrame(frameTimeNanos: Long) {
        if (!isLoopRunning) return
        if (lastFrameNanos == 0L) {
            lastFrameNanos = frameTimeNanos
            Choreographer.getInstance().postFrameCallback(this)
            return
        }

        val deltaNanos = frameTimeNanos - lastFrameNanos
        lastFrameNanos = frameTimeNanos
        accumulatedNanos += deltaNanos

        val minFrameIntervalNanos = 1_000_000_000L / targetFps.fps
        if (accumulatedNanos >= minFrameIntervalNanos) {
            val dtSec = (accumulatedNanos / 1_000_000_000f).coerceIn(0.001f, 0.05f)
            accumulatedNanos = 0L

            engine.step(dtSec, quality.particleFactor)
            invalidate()

            hudUpdateAccumulator += dtSec
            if (hudUpdateAccumulator >= 0.032f) {
                hudUpdateAccumulator = 0f
                onHudUpdate?.invoke(engine.snapshot())
            }
        }

        Choreographer.getInstance().postFrameCallback(this)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        renderer.render(
            canvas = canvas,
            width = w,
            height = h,
            engine = engine,
            ballSkin = ballSkin,
            trailSkin = trailSkin,
            theme = arenaTheme,
            arenaBoundsOut = arenaBounds
        )
    }

    private fun toNormX(rawX: Float): Float {
        val aw = arenaBounds.width().coerceAtLeast(1f)
        return ((rawX - arenaBounds.left) / aw).coerceIn(0f, 1f)
    }

    private fun toNormY(rawY: Float): Float {
        val ah = arenaBounds.height().coerceAtLeast(1f)
        return ((rawY - arenaBounds.top) / ah).coerceIn(0f, 1f)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (engine.phase == RunPhase.MENU_DEMO) {
            return false
        }

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downY = event.y
                lastMoveX = event.x
                lastMoveY = event.y
                downTimeMs = event.eventTime
                swipeTriggered = false

                val nx = toNormX(event.x)
                val ny = toNormY(event.y)
                if (engine.phase == RunPhase.READY) {
                    engine.launchIfReady()
                    onHudUpdate?.invoke(engine.snapshot())
                } else {
                    engine.onDrag(nx, ny, active = true)
                }
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val nx = toNormX(event.x)
                val ny = toNormY(event.y)
                engine.onDrag(nx, ny, active = true)

                val totalDx = event.x - downX
                val totalDy = event.y - downY
                val distPx = hypot(totalDx, totalDy)
                val elapsedMs = (event.eventTime - downTimeMs).coerceAtLeast(1L)

                // Fast flick / swipe detection
                if (!swipeTriggered && distPx > width * 0.085f && elapsedMs < 240L) {
                    swipeTriggered = true
                    val aw = arenaBounds.width().coerceAtLeast(1f)
                    val ah = arenaBounds.height().coerceAtLeast(1f)
                    engine.onSwipe(
                        dxNorm = totalDx / aw,
                        dyNorm = totalDy / ah,
                        startX = toNormX(downX),
                        startY = toNormY(downY)
                    )
                }
                lastMoveX = event.x
                lastMoveY = event.y
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val nx = toNormX(event.x)
                val ny = toNormY(event.y)
                engine.onDrag(nx, ny, active = false)

                val distPx = hypot(event.x - downX, event.y - downY)
                val elapsedMs = event.eventTime - downTimeMs
                if (!swipeTriggered && distPx < width * 0.045f && elapsedMs < 260L) {
                    engine.onTap(nx, ny)
                }
                performClick()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        return super.performClick()
    }
}
