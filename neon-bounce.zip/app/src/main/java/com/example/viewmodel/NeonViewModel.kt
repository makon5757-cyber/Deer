package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.example.audio.NeonAudioEngine
import com.example.data.GameRepository
import com.example.engine.EngineAudioCallbacks
import com.example.engine.HudSnapshot
import com.example.engine.NeonPhysicsEngine
import com.example.engine.RunPhase
import com.example.model.AppLanguage
import com.example.model.AppState
import com.example.model.GameCatalog
import com.example.model.GameMode
import com.example.model.GraphicsQuality
import com.example.model.LevelConfig
import com.example.model.ScreenRoute
import com.example.model.TargetFps
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class NeonViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = GameRepository(application)
    val audio = NeonAudioEngine(application)

    val appState: StateFlow<AppState> = repository.state

    private val _currentRoute = MutableStateFlow(ScreenRoute.MENU)
    val currentRoute: StateFlow<ScreenRoute> = _currentRoute.asStateFlow()

    private val _hudSnapshot = MutableStateFlow(HudSnapshot())
    val hudSnapshot: StateFlow<HudSnapshot> = _hudSnapshot.asStateFlow()

    private val _shopToastKey = MutableStateFlow<String?>(null)
    val shopToastKey: StateFlow<String?> = _shopToastKey.asStateFlow()

    private var activeEngine: NeonPhysicsEngine? = null
    private var currentLevel: LevelConfig? = null

    init {
        val initialSettings = repository.state.value.settings
        audio.applySettings(
            music = initialSettings.musicEnabled,
            sound = initialSettings.soundEnabled,
            vibration = initialSettings.vibrationEnabled
        )
    }

    fun attachEngine(engine: NeonPhysicsEngine) {
        if (activeEngine === engine) return
        activeEngine = engine
        engine.audioCallbacks = object : EngineAudioCallbacks {
            override fun onWallBounce(intensity: Float) {
                audio.playWallBounce(intensity)
                audio.vibrateLight()
            }

            override fun onWaveBounce(combo: Int) {
                audio.playWaveBounce(combo)
                audio.vibrateLight()
            }

            override fun onMilestoneUp(tierIndex: Int, isNewRecord: Boolean) {
                if (isNewRecord) {
                    audio.playNewRecord()
                } else {
                    audio.playMilestoneUp(tierIndex)
                }
                audio.vibrateStrong()
            }

            override fun onEnergyBurst() {
                audio.playBurst()
                audio.vibrateStrong()
            }

            override fun onLevelComplete() {
                audio.playLevelWin()
                audio.vibrateStrong()
            }

            override fun onGameOver() {
                audio.playGameOver()
                audio.vibrateStrong()
            }
        }

        engine.onRunFinished = { snap ->
            repository.recordRunResult(
                mode = snap.mode,
                milestoneReached = snap.scoreMilestone,
                bouncesInRun = snap.bounces,
                earnedShards = snap.earnedShards,
                levelNumber = snap.levelNumber,
                levelCleared = snap.phase == RunPhase.LEVEL_COMPLETE,
                starsEarned = snap.starsEarned
            )
            _hudSnapshot.value = snap
        }
    }

    fun updateHudFromEngine(snap: HudSnapshot) {
        _hudSnapshot.value = snap
    }

    fun navigateTo(route: ScreenRoute) {
        audio.playUiClick()
        if (route == ScreenRoute.MENU) {
            activeEngine?.startMenuDemo()
        }
        _currentRoute.value = route
    }

    fun startClassic() {
        audio.playUiClick()
        currentLevel = null
        val best = appState.value.progress.bestClassicScore
        activeEngine?.startNewGame(GameMode.CLASSIC, bestScore = best, level = null, keepAuto = false)
        _hudSnapshot.value = activeEngine?.snapshot() ?: HudSnapshot()
        _currentRoute.value = ScreenRoute.GAME
    }

    fun startEndless() {
        audio.playUiClick()
        currentLevel = null
        val best = appState.value.progress.bestEndlessScore
        activeEngine?.startNewGame(GameMode.ENDLESS, bestScore = best, level = null, keepAuto = false)
        _hudSnapshot.value = activeEngine?.snapshot() ?: HudSnapshot()
        _currentRoute.value = ScreenRoute.GAME
    }

    fun startLevel(levelNumber: Int) {
        audio.playUiClick()
        val lvl = GameCatalog.levels.firstOrNull { it.number == levelNumber } ?: GameCatalog.levels.first()
        currentLevel = lvl
        activeEngine?.startNewGame(GameMode.LEVELS, bestScore = lvl.targetMilestone, level = lvl, keepAuto = false)
        _hudSnapshot.value = activeEngine?.snapshot() ?: HudSnapshot()
        _currentRoute.value = ScreenRoute.GAME
    }

    fun restartCurrentRun() {
        audio.playUiClick()
        val snap = _hudSnapshot.value
        val keepAuto = activeEngine?.autoMode ?: false
        val best = when (snap.mode) {
            GameMode.CLASSIC -> appState.value.progress.bestClassicScore
            GameMode.ENDLESS -> appState.value.progress.bestEndlessScore
            GameMode.LEVELS -> currentLevel?.targetMilestone ?: 16
        }
        activeEngine?.startNewGame(snap.mode, bestScore = best, level = currentLevel, keepAuto = keepAuto)
        _hudSnapshot.value = activeEngine?.snapshot() ?: HudSnapshot()
    }

    fun startNextLevel() {
        val nextNum = ((currentLevel?.number ?: 1) + 1).coerceAtMost(50)
        startLevel(nextNum)
    }

    fun togglePause() {
        audio.playUiClick()
        val eng = activeEngine ?: return
        if (eng.phase == RunPhase.PLAYING) {
            eng.pause()
        } else if (eng.phase == RunPhase.PAUSED) {
            eng.resume()
        }
        _hudSnapshot.value = eng.snapshot()
    }

    fun toggleAutoMode() {
        audio.playUiClick()
        val eng = activeEngine ?: return
        eng.autoMode = !eng.autoMode
        if (eng.phase == RunPhase.READY && eng.autoMode) {
            eng.launchIfReady()
        }
        _hudSnapshot.value = eng.snapshot()
    }

    fun claimDailyReward(): Int {
        audio.playUiClick()
        val reward = repository.claimDailyReward()
        if (reward > 0) {
            audio.playMilestoneUp(2)
            audio.vibrateStrong()
        }
        return reward
    }

    fun buyOrEquipBall(id: String): Boolean {
        audio.playUiClick()
        val ok = repository.buyOrEquipBall(id)
        if (ok) audio.playMilestoneUp(1) else _shopToastKey.value = "not_enough"
        return ok
    }

    fun buyOrEquipTrail(id: String): Boolean {
        audio.playUiClick()
        val ok = repository.buyOrEquipTrail(id)
        if (ok) audio.playMilestoneUp(1) else _shopToastKey.value = "not_enough"
        return ok
    }

    fun buyOrEquipTheme(id: String): Boolean {
        audio.playUiClick()
        val ok = repository.buyOrEquipTheme(id)
        if (ok) audio.playMilestoneUp(1) else _shopToastKey.value = "not_enough"
        return ok
    }

    fun clearShopToast() {
        _shopToastKey.value = null
    }

    fun toggleMusic() {
        audio.playUiClick()
        repository.updateSettings { it.copy(musicEnabled = !it.musicEnabled) }
        syncAudioSettings()
    }

    fun toggleSound() {
        repository.updateSettings { it.copy(soundEnabled = !it.soundEnabled) }
        syncAudioSettings()
        audio.playUiClick()
    }

    fun toggleVibration() {
        audio.playUiClick()
        repository.updateSettings { it.copy(vibrationEnabled = !it.vibrationEnabled) }
        syncAudioSettings()
        audio.vibrateLight()
    }

    fun setGraphicsQuality(quality: GraphicsQuality) {
        audio.playUiClick()
        repository.updateSettings { it.copy(graphicsQuality = quality) }
    }

    fun setTargetFps(fps: TargetFps) {
        audio.playUiClick()
        repository.updateSettings { it.copy(targetFps = fps) }
    }

    fun setLanguage(language: AppLanguage) {
        audio.playUiClick()
        repository.updateSettings { it.copy(language = language) }
    }

    private fun syncAudioSettings() {
        val s = repository.state.value.settings
        audio.applySettings(s.musicEnabled, s.soundEnabled, s.vibrationEnabled)
    }

    fun onAppResume() {
        audio.onResume()
    }

    fun onAppPause() {
        audio.onPause()
        if (_currentRoute.value == ScreenRoute.GAME && activeEngine?.phase == RunPhase.PLAYING) {
            activeEngine?.pause()
            _hudSnapshot.value = activeEngine?.snapshot() ?: _hudSnapshot.value
        }
    }

    override fun onCleared() {
        audio.release()
        super.onCleared()
    }
}
