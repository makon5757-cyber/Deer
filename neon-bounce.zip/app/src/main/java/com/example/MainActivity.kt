package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.localization.Localization
import com.example.model.GameCatalog
import com.example.model.ScreenRoute
import com.example.ui.screens.GameHudScreen
import com.example.ui.screens.LevelsScreen
import com.example.ui.screens.MainMenuScreen
import com.example.ui.screens.RecordsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.ShopScreen
import com.example.ui.theme.NeonBounceTheme
import com.example.ui.theme.VoidBlack
import com.example.view.NeonArenaView
import com.example.viewmodel.NeonViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: NeonViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.BLACK),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.BLACK)
        )
        setContent {
            NeonBounceApp(viewModel = viewModel)
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.onAppResume()
    }

    override fun onPause() {
        viewModel.onAppPause()
        super.onPause()
    }
}

@Composable
fun NeonBounceApp(viewModel: NeonViewModel) {
    val appState by viewModel.appState.collectAsStateWithLifecycle()
    val currentRoute by viewModel.currentRoute.collectAsStateWithLifecycle()
    val hudSnapshot by viewModel.hudSnapshot.collectAsStateWithLifecycle()
    val shopToastKey by viewModel.shopToastKey.collectAsStateWithLifecycle()

    val strings = Localization.forLanguage(appState.settings.language)
    val equippedBall = GameCatalog.getBallSkin(appState.progress.equippedBallId)
    val equippedTrail = GameCatalog.getTrailSkin(appState.progress.equippedTrailId)
    val activeTheme = GameCatalog.getArenaTheme(appState.settings.selectedThemeId)

    NeonBounceTheme(
        accentColor = Color(activeTheme.borderColor),
        secondaryAccent = Color(activeTheme.palette.getOrElse(3) { 0xFFFF2E93 })
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(VoidBlack)
        ) {
            // Live hardware-accelerated Canvas game arena & animated menu background
            AndroidView(
                factory = { ctx ->
                    NeonArenaView(ctx).also { arenaView ->
                        viewModel.attachEngine(arenaView.engine)
                        arenaView.onHudUpdate = { snap ->
                            viewModel.updateHudFromEngine(snap)
                        }
                    }
                },
                update = { arenaView ->
                    arenaView.applyVisualConfig(
                        ball = equippedBall,
                        trail = equippedTrail,
                        theme = activeTheme,
                        graphicsQuality = appState.settings.graphicsQuality,
                        fps = appState.settings.targetFps
                    )
                },
                modifier = Modifier.fillMaxSize()
            )

            Crossfade(
                targetState = currentRoute,
                animationSpec = tween(220),
                label = "screen_route"
            ) { route ->
                when (route) {
                    ScreenRoute.MENU -> MainMenuScreen(
                        appState = appState,
                        strings = strings,
                        onPlay = { viewModel.startClassic() },
                        onLevels = { viewModel.navigateTo(ScreenRoute.LEVELS) },
                        onEndless = { viewModel.startEndless() },
                        onSkins = { viewModel.navigateTo(ScreenRoute.SHOP) },
                        onRecords = { viewModel.navigateTo(ScreenRoute.RECORDS) },
                        onSettings = { viewModel.navigateTo(ScreenRoute.SETTINGS) },
                        onClaimDaily = { viewModel.claimDailyReward() }
                    )

                    ScreenRoute.GAME -> GameHudScreen(
                        hud = hudSnapshot,
                        strings = strings,
                        onTogglePause = { viewModel.togglePause() },
                        onToggleAuto = { viewModel.toggleAutoMode() },
                        onRestart = { viewModel.restartCurrentRun() },
                        onNextLevel = { viewModel.startNextLevel() },
                        onExitToMenu = { viewModel.navigateTo(ScreenRoute.MENU) }
                    )

                    ScreenRoute.LEVELS -> LevelsScreen(
                        appState = appState,
                        strings = strings,
                        onSelectLevel = { lvl -> viewModel.startLevel(lvl) },
                        onBack = { viewModel.navigateTo(ScreenRoute.MENU) }
                    )

                    ScreenRoute.SHOP -> ShopScreen(
                        appState = appState,
                        strings = strings,
                        shopToastKey = shopToastKey,
                        onClearToast = { viewModel.clearShopToast() },
                        onBuyOrEquipBall = { viewModel.buyOrEquipBall(it) },
                        onBuyOrEquipTrail = { viewModel.buyOrEquipTrail(it) },
                        onBuyOrEquipTheme = { viewModel.buyOrEquipTheme(it) },
                        onClaimDaily = { viewModel.claimDailyReward() },
                        onBack = { viewModel.navigateTo(ScreenRoute.MENU) }
                    )

                    ScreenRoute.RECORDS -> RecordsScreen(
                        appState = appState,
                        strings = strings,
                        onBack = { viewModel.navigateTo(ScreenRoute.MENU) }
                    )

                    ScreenRoute.SETTINGS -> SettingsScreen(
                        appState = appState,
                        strings = strings,
                        onToggleMusic = { viewModel.toggleMusic() },
                        onToggleSound = { viewModel.toggleSound() },
                        onToggleVibration = { viewModel.toggleVibration() },
                        onSelectQuality = { viewModel.setGraphicsQuality(it) },
                        onSelectFps = { viewModel.setTargetFps(it) },
                        onSelectTheme = { viewModel.buyOrEquipTheme(it) },
                        onSelectLanguage = { viewModel.setLanguage(it) },
                        onBack = { viewModel.navigateTo(ScreenRoute.MENU) }
                    )
                }
            }
        }
    }
}
