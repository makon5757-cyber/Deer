package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val VoidBlack = Color(0xFF000000)
val DeepObsidian = Color(0xFF060811)
val NeonSurface = Color(0xFF0D111D)
val NeonSurfaceElevated = Color(0xFF151B2E)
val NeonBorderSubtle = Color(0xFF232C47)

val NeonCyan = Color(0xFF00F0FF)
val NeonBlue = Color(0xFF0088FF)
val NeonViolet = Color(0xFF9D4EDD)
val NeonMagenta = Color(0xFFFF2E93)
val NeonEmerald = Color(0xFF00FF87)
val NeonGold = Color(0xFFFFE600)
val PureWhite = Color(0xFFFFFFFF)
val MutedText = Color(0xFF94A3B8)
