package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.localization.GameStrings
import com.example.model.AppLanguage
import com.example.model.AppState
import com.example.model.GameCatalog
import com.example.model.GraphicsQuality
import com.example.model.TargetFps
import com.example.ui.theme.MutedText
import com.example.ui.theme.NeonSurface
import com.example.ui.theme.PureWhite
import com.example.ui.theme.VoidBlack

@Composable
fun SettingsScreen(
    appState: AppState,
    strings: GameStrings,
    onToggleMusic: () -> Unit,
    onToggleSound: () -> Unit,
    onToggleVibration: () -> Unit,
    onSelectQuality: (GraphicsQuality) -> Unit,
    onSelectFps: (TargetFps) -> Unit,
    onSelectTheme: (String) -> Unit,
    onSelectLanguage: (AppLanguage) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val settings = appState.settings
    val accent = MaterialTheme.colorScheme.primary

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(VoidBlack.copy(alpha = 0.90f))
            .safeDrawingPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp)
                .align(Alignment.Center)
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("settings_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = strings.back, tint = PureWhite)
                }
                Spacer(Modifier.width(8.dp))
                Text(strings.settings, style = MaterialTheme.typography.headlineMedium, color = PureWhite)
            }

            // Music, Sound, Vibration toggles
            SettingToggleRow(
                title = strings.music,
                checked = settings.musicEnabled,
                icon = Icons.Rounded.MusicNote,
                accent = accent,
                strings = strings,
                testTag = "setting_music_toggle",
                onToggle = onToggleMusic
            )
            SettingToggleRow(
                title = strings.sounds,
                checked = settings.soundEnabled,
                icon = Icons.Rounded.VolumeUp,
                accent = accent,
                strings = strings,
                testTag = "setting_sound_toggle",
                onToggle = onToggleSound
            )
            SettingToggleRow(
                title = strings.vibration,
                checked = settings.vibrationEnabled,
                icon = Icons.Rounded.Vibration,
                accent = accent,
                strings = strings,
                testTag = "setting_vibration_toggle",
                onToggle = onToggleVibration
            )

            // Graphics Quality (controls wave line count & blur)
            SettingSectionCard(title = strings.graphicsQuality, icon = Icons.Rounded.Tune, accent = accent) {
                val options = listOf(
                    GraphicsQuality.LOW to strings.qualityLow,
                    GraphicsQuality.MEDIUM to strings.qualityMedium,
                    GraphicsQuality.HIGH to strings.qualityHigh,
                    GraphicsQuality.ULTRA to strings.qualityUltra
                )
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    options.forEach { (q, label) ->
                        val selected = settings.graphicsQuality == q
                        ChoiceChipRow(
                            label = label,
                            selected = selected,
                            accent = accent,
                            testTag = "quality_${q.name}",
                            onClick = { onSelectQuality(q) }
                        )
                    }
                }
            }

            // Target Frame Rate
            SettingSectionCard(title = strings.frameRate, icon = Icons.Rounded.Speed, accent = accent) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TargetFps.entries.forEach { fps ->
                        val selected = settings.targetFps == fps
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) accent.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.05f),
                            border = BorderStroke(1.dp, if (selected) accent else Color.White.copy(alpha = 0.14f)),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("fps_${fps.fps}")
                                .clickable { onSelectFps(fps) }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "${fps.fps} FPS",
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (selected) accent else PureWhite
                                )
                            }
                        }
                    }
                }
            }

            // Color Theme selector (unlocked themes)
            SettingSectionCard(title = strings.colorTheme, icon = Icons.Rounded.Palette, accent = accent) {
                val unlockedThemes = GameCatalog.arenaThemes.filter { it.id in appState.progress.unlockedThemeIds }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    unlockedThemes.forEach { theme ->
                        val selected = settings.selectedThemeId == theme.id
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) accent.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.04f),
                            border = BorderStroke(1.dp, if (selected) accent else Color.White.copy(alpha = 0.12f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("theme_select_${theme.id}")
                                .clickable { onSelectTheme(theme.id) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = strings.itemNames[theme.nameKey] ?: theme.id,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = if (selected) accent else PureWhite,
                                    modifier = Modifier.weight(1f)
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    theme.palette.take(4).forEach { hex ->
                                        Box(
                                            modifier = Modifier
                                                .size(12.dp)
                                                .background(Color(hex), CircleShape)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Language selector (Russian / English / Tajik)
            SettingSectionCard(title = strings.language, icon = Icons.Rounded.Language, accent = accent) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppLanguage.entries.forEach { lang ->
                        val selected = settings.language == lang
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) accent.copy(alpha = 0.22f) else Color.White.copy(alpha = 0.05f),
                            border = BorderStroke(1.dp, if (selected) accent else Color.White.copy(alpha = 0.14f)),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("lang_${lang.code}")
                                .clickable { onSelectLanguage(lang) }
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = lang.nativeLabel,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (selected) accent else PureWhite
                                )
                            }
                        }
                    }
                }
            }

            // Developer credit footer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.GraphicEq, contentDescription = null, tint = accent, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("${strings.appTitle} • ${strings.developer}", style = MaterialTheme.typography.labelSmall, color = MutedText)
            }
        }
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    checked: Boolean,
    icon: ImageVector,
    accent: Color,
    strings: GameStrings,
    testTag: String,
    onToggle: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = NeonSurface,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onToggle)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(12.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, color = PureWhite, modifier = Modifier.weight(1f))
            Text(
                text = if (checked) strings.on else strings.off,
                style = MaterialTheme.typography.labelSmall,
                color = if (checked) accent else MutedText,
                modifier = Modifier.padding(end = 10.dp)
            )
            Switch(
                checked = checked,
                onCheckedChange = { onToggle() },
                modifier = Modifier.testTag(testTag),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.Black,
                    checkedTrackColor = accent
                )
            )
        }
    }
}

@Composable
private fun SettingSectionCard(
    title: String,
    icon: ImageVector,
    accent: Color,
    content: @Composable () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = NeonSurface,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.14f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = title, tint = accent, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun ChoiceChipRow(
    label: String,
    selected: Boolean,
    accent: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = if (selected) accent.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.04f),
        border = BorderStroke(1.dp, if (selected) accent else Color.White.copy(alpha = 0.12f)),
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag(testTag)
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 14.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyLarge,
                color = if (selected) accent else PureWhite
            )
        }
    }
}
