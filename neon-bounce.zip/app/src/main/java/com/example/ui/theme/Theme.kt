package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun NeonBounceTheme(
    accentColor: Color = NeonCyan,
    secondaryAccent: Color = NeonMagenta,
    content: @Composable () -> Unit
) {
    val colorScheme = darkColorScheme(
        primary = accentColor,
        onPrimary = VoidBlack,
        primaryContainer = NeonSurfaceElevated,
        onPrimaryContainer = PureWhite,
        secondary = secondaryAccent,
        onSecondary = PureWhite,
        tertiary = NeonViolet,
        background = VoidBlack,
        onBackground = PureWhite,
        surface = NeonSurface,
        onSurface = PureWhite,
        surfaceVariant = NeonSurfaceElevated,
        onSurfaceVariant = MutedText,
        outline = NeonBorderSubtle
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = NeonTypography,
        content = content
    )
}
