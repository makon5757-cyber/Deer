package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.localization.GameStrings
import com.example.model.AppState
import com.example.model.GameCatalog
import com.example.ui.theme.MutedText
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonSurface
import com.example.ui.theme.PureWhite
import com.example.ui.theme.VoidBlack

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RecordsScreen(
    appState: AppState,
    strings: GameStrings,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val prog = appState.progress
    val accent = MaterialTheme.colorScheme.primary

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(VoidBlack.copy(alpha = 0.90f))
            .safeDrawingPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp)
                .align(Alignment.Center)
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("records_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = strings.back, tint = PureWhite)
                }
                Spacer(Modifier.width(8.dp))
                Text(strings.records, style = MaterialTheme.typography.headlineMedium, color = PureWhite)
            }

            Spacer(Modifier.height(14.dp))

            // Primary Record Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                RecordStatCard(
                    title = strings.bestClassic,
                    value = "${prog.bestClassicScore.coerceAtLeast(1)}",
                    accent = NeonCyan,
                    modifier = Modifier.weight(1f)
                )
                RecordStatCard(
                    title = strings.bestEndless,
                    value = "${prog.bestEndlessScore.coerceAtLeast(1)}",
                    accent = NeonMagenta,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                RecordStatCard(
                    title = strings.highestMilestone,
                    value = "${prog.highestMilestone}",
                    accent = NeonGold,
                    modifier = Modifier.weight(1f)
                )
                RecordStatCard(
                    title = strings.levelsCompleted,
                    value = "${prog.levelStars.size}/50",
                    accent = NeonEmerald,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                RecordStatCard(
                    title = strings.totalBounces,
                    value = "${prog.totalBounces}",
                    accent = accent,
                    modifier = Modifier.weight(1f)
                )
                RecordStatCard(
                    title = strings.gamesPlayed,
                    value = "${prog.totalGamesPlayed}",
                    accent = PureWhite,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(22.dp))

            Text(
                text = strings.milestoneLadder,
                style = MaterialTheme.typography.titleLarge,
                color = PureWhite
            )
            Spacer(Modifier.height(12.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                GameCatalog.milestoneSequence.forEach { milestone ->
                    val reached = prog.highestMilestone >= milestone
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (reached) accent.copy(alpha = 0.22f) else NeonSurface,
                        border = BorderStroke(
                            1.dp,
                            if (reached) accent else Color.White.copy(alpha = 0.14f)
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (reached) {
                                Icon(
                                    imageVector = Icons.Rounded.EmojiEvents,
                                    contentDescription = null,
                                    tint = NeonGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(6.dp))
                            }
                            Text(
                                text = "$milestone",
                                style = MaterialTheme.typography.labelLarge,
                                color = if (reached) PureWhite else MutedText.copy(alpha = 0.5f)
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun RecordStatCard(
    title: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = NeonSurface,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.42f))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall, color = MutedText)
            Spacer(Modifier.height(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold),
                color = accent
            )
        }
    }
}
