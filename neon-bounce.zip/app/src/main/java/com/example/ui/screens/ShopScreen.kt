package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.localization.GameStrings
import com.example.model.AppState
import com.example.model.GameCatalog
import com.example.ui.theme.MutedText
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonSurface
import com.example.ui.theme.PureWhite
import com.example.ui.theme.VoidBlack

@Composable
fun ShopScreen(
    appState: AppState,
    strings: GameStrings,
    shopToastKey: String?,
    onClearToast: () -> Unit,
    onBuyOrEquipBall: (String) -> Unit,
    onBuyOrEquipTrail: (String) -> Unit,
    onBuyOrEquipTheme: (String) -> Unit,
    onClaimDaily: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    var selectedTab by remember { mutableIntStateOf(0) }
    val snackbarHostState = remember { SnackbarHostState() }
    val accent = MaterialTheme.colorScheme.primary

    LaunchedEffect(shopToastKey) {
        if (shopToastKey == "not_enough") {
            snackbarHostState.showSnackbar(strings.notEnoughShards)
            onClearToast()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(VoidBlack.copy(alpha = 0.90f))
            .safeDrawingPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp)
                .align(Alignment.Center)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("shop_back_button")
                ) {
                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = strings.back, tint = PureWhite)
                }
                Spacer(Modifier.width(8.dp))
                Text(
                    text = strings.skins,
                    style = MaterialTheme.typography.headlineMedium,
                    color = PureWhite
                )
                Spacer(Modifier.weight(1f))
                Surface(
                    shape = RoundedCornerShape(50),
                    color = NeonSurface,
                    border = BorderStroke(1.dp, accent.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Bolt, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("${appState.progress.shards}", style = MaterialTheme.typography.labelLarge, color = PureWhite)
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Daily Reward Card (100% offline)
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = NeonSurface,
                border = BorderStroke(
                    1.dp,
                    if (appState.canClaimDailyReward) NeonGold.copy(alpha = 0.8f) else Color.White.copy(alpha = 0.14f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Rounded.CardGiftcard,
                        contentDescription = strings.dailyReward,
                        tint = if (appState.canClaimDailyReward) NeonGold else MutedText,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(strings.dailyReward, style = MaterialTheme.typography.titleMedium, color = PureWhite)
                        Text(
                            text = "${strings.streakDays}: ${appState.progress.dailyStreak}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MutedText
                        )
                    }
                    Button(
                        onClick = onClaimDaily,
                        enabled = appState.canClaimDailyReward,
                        modifier = Modifier.testTag("shop_claim_daily_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonGold,
                            contentColor = Color.Black,
                            disabledContainerColor = Color.White.copy(alpha = 0.1f),
                            disabledContentColor = MutedText
                        )
                    ) {
                        Text(
                            text = if (appState.canClaimDailyReward) {
                                "${strings.claimReward} +${appState.nextDailyRewardAmount}"
                            } else {
                                strings.claimedToday
                            },
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Category Tabs
            val tabs = listOf(strings.tabBalls, strings.tabTrails, strings.tabThemes)
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = NeonSurface,
                contentColor = accent,
                modifier = Modifier.fillMaxWidth()
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        modifier = Modifier.testTag("shop_tab_$index"),
                        text = {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelLarge,
                                color = if (selectedTab == index) accent else MutedText
                            )
                        }
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            LazyColumn(
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                when (selectedTab) {
                    0 -> items(GameCatalog.ballSkins, key = { it.id }) { skin ->
                        val unlocked = skin.id in appState.progress.unlockedBallIds
                        val equipped = skin.id == appState.progress.equippedBallId
                        ShopItemRow(
                            title = strings.itemNames[skin.nameKey] ?: skin.id,
                            cost = skin.cost,
                            unlocked = unlocked,
                            equipped = equipped,
                            strings = strings,
                            previewContent = {
                                Canvas(modifier = Modifier.size(40.dp)) {
                                    drawCircle(
                                        brush = Brush.radialGradient(
                                            listOf(
                                                Color(skin.coreColor),
                                                Color(skin.primaryColor),
                                                Color(skin.secondaryColor).copy(alpha = 0.25f)
                                            )
                                        ),
                                        radius = size.minDimension * 0.45f
                                    )
                                }
                            },
                            testTag = "buy_ball_${skin.id}",
                            onAction = { onBuyOrEquipBall(skin.id) }
                        )
                    }

                    1 -> items(GameCatalog.trailSkins, key = { it.id }) { trail ->
                        val unlocked = trail.id in appState.progress.unlockedTrailIds
                        val equipped = trail.id == appState.progress.equippedTrailId
                        ShopItemRow(
                            title = strings.itemNames[trail.nameKey] ?: trail.id,
                            cost = trail.cost,
                            unlocked = unlocked,
                            equipped = equipped,
                            strings = strings,
                            previewContent = {
                                Canvas(modifier = Modifier.size(40.dp)) {
                                    val c = Color(trail.accentColor)
                                    drawLine(
                                        brush = Brush.linearGradient(listOf(Color.Transparent, c, Color.White)),
                                        start = Offset(4f, size.height * 0.78f),
                                        end = Offset(size.width - 6f, size.height * 0.22f),
                                        strokeWidth = 7f
                                    )
                                }
                            },
                            testTag = "buy_trail_${trail.id}",
                            onAction = { onBuyOrEquipTrail(trail.id) }
                        )
                    }

                    else -> items(GameCatalog.arenaThemes, key = { it.id }) { theme ->
                        val unlocked = theme.id in appState.progress.unlockedThemeIds
                        val equipped = theme.id == appState.settings.selectedThemeId
                        ShopItemRow(
                            title = strings.itemNames[theme.nameKey] ?: theme.id,
                            cost = theme.cost,
                            unlocked = unlocked,
                            equipped = equipped,
                            strings = strings,
                            previewContent = {
                                Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                    theme.palette.take(4).forEach { hex ->
                                        Box(
                                            modifier = Modifier
                                                .size(9.dp, 28.dp)
                                                .background(Color(hex), CircleShape)
                                        )
                                    }
                                }
                            },
                            testTag = "buy_theme_${theme.id}",
                            onAction = { onBuyOrEquipTheme(theme.id) }
                        )
                    }
                }
            }
        }

        SnackbarHost(
            hostState = snackbarHostState,
            modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
private fun ShopItemRow(
    title: String,
    cost: Int,
    unlocked: Boolean,
    equipped: Boolean,
    strings: GameStrings,
    previewContent: @Composable () -> Unit,
    testTag: String,
    onAction: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = NeonSurface,
        border = BorderStroke(
            width = if (equipped) 1.5.dp else 1.dp,
            color = if (equipped) NeonEmerald else Color.White.copy(alpha = 0.14f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(44.dp),
                contentAlignment = Alignment.Center
            ) {
                previewContent()
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = PureWhite)
                if (!unlocked) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Bolt, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(3.dp))
                        Text("$cost", style = MaterialTheme.typography.labelSmall, color = NeonCyan)
                    }
                }
            }
            Button(
                onClick = onAction,
                modifier = Modifier.testTag(testTag),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = when {
                        equipped -> NeonEmerald.copy(alpha = 0.22f)
                        unlocked -> Color.White.copy(alpha = 0.14f)
                        else -> MaterialTheme.colorScheme.primary
                    },
                    contentColor = when {
                        equipped -> NeonEmerald
                        unlocked -> PureWhite
                        else -> Color.Black
                    }
                )
            ) {
                if (equipped) {
                    Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(strings.equipped, style = MaterialTheme.typography.labelSmall)
                } else if (unlocked) {
                    Text(strings.equip, style = MaterialTheme.typography.labelSmall)
                } else {
                    Text("${strings.buy} ($cost)", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
