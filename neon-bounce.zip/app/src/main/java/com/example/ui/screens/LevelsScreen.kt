package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.localization.GameStrings
import com.example.model.AppState
import com.example.model.GameCatalog
import com.example.model.LevelConfig
import com.example.ui.theme.MutedText
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonSurface
import com.example.ui.theme.PureWhite
import com.example.ui.theme.VoidBlack

@Composable
fun LevelsScreen(
    appState: AppState,
    strings: GameStrings,
    onSelectLevel: (Int) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val accent = MaterialTheme.colorScheme.primary
    val highestUnlocked = appState.progress.highestUnlockedLevel

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(VoidBlack.copy(alpha = 0.88f))
            .safeDrawingPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("levels_back_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = strings.back,
                    tint = PureWhite
                )
            }
            Spacer(Modifier.width(8.dp))
            Text(
                text = "${strings.levels} (50)",
                style = MaterialTheme.typography.headlineMedium,
                color = PureWhite
            )
            Spacer(Modifier.weight(1f))
            Text(
                text = "${appState.progress.levelStars.size}/50",
                style = MaterialTheme.typography.labelLarge,
                color = accent
            )
        }

        Spacer(Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 94.dp),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(GameCatalog.levels, key = { it.number }) { level ->
                val unlocked = level.number <= highestUnlocked
                val stars = appState.progress.levelStars[level.number] ?: 0
                LevelTile(
                    level = level,
                    unlocked = unlocked,
                    stars = stars,
                    accent = accent,
                    strings = strings,
                    onClick = { if (unlocked) onSelectLevel(level.number) }
                )
            }
        }
    }
}

@Composable
private fun LevelTile(
    level: LevelConfig,
    unlocked: Boolean,
    stars: Int,
    accent: Color,
    strings: GameStrings,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (unlocked) NeonSurface.copy(alpha = 0.92f) else Color(0xFF070910),
        border = BorderStroke(
            width = if (stars > 0) 1.4.dp else 1.dp,
            color = when {
                !unlocked -> Color.White.copy(alpha = 0.09f)
                stars > 0 -> accent.copy(alpha = 0.7f)
                else -> Color.White.copy(alpha = 0.28f)
            }
        ),
        modifier = Modifier
            .height(98.dp)
            .testTag("level_tile_${level.number}")
            .clickable(enabled = unlocked, onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
        ) {
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (unlocked) {
                    Text(
                        text = "${level.number}",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                        color = PureWhite
                    )
                    Text(
                        text = "${strings.target} ${level.targetMilestone}",
                        style = MaterialTheme.typography.labelSmall,
                        color = accent
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        repeat(3) { idx ->
                            Icon(
                                imageVector = Icons.Rounded.Star,
                                contentDescription = null,
                                tint = if (idx < stars) NeonGold else Color.White.copy(alpha = 0.14f),
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                } else {
                    Icon(
                        imageVector = Icons.Rounded.Lock,
                        contentDescription = null,
                        tint = MutedText.copy(alpha = 0.45f),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "${level.number}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MutedText.copy(alpha = 0.45f)
                    )
                }
            }
        }
    }
}
