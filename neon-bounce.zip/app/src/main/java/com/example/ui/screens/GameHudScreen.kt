package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SmartToy
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.HudSnapshot
import com.example.engine.RunPhase
import com.example.localization.GameStrings
import com.example.model.GameMode
import com.example.ui.theme.MutedText
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonSurface
import com.example.ui.theme.PureWhite

@Composable
fun GameHudScreen(
    hud: HudSnapshot,
    strings: GameStrings,
    onTogglePause: () -> Unit,
    onToggleAuto: () -> Unit,
    onRestart: () -> Unit,
    onNextLevel: () -> Unit,
    onExitToMenu: () -> Unit
) {
    BackHandler {
        when (hud.phase) {
            RunPhase.PLAYING -> onTogglePause()
            RunPhase.PAUSED -> onTogglePause()
            else -> onExitToMenu()
        }
    }

    val scoreScale = remember { Animatable(1f) }
    LaunchedEffect(hud.milestoneEventId) {
        if (hud.milestoneEventId > 0) {
            scoreScale.snapTo(1.42f)
            scoreScale.animateTo(
                targetValue = 1f,
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioMediumBouncy,
                    stiffness = Spring.StiffnessMedium
                )
            )
        }
    }

    val accent = MaterialTheme.colorScheme.primary

    Box(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        // Top Controls + Giant White Score Number directly above the arena
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Pause button
                Surface(
                    shape = CircleShape,
                    color = NeonSurface.copy(alpha = 0.78f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
                ) {
                    IconButton(
                        onClick = onTogglePause,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("game_pause_button")
                    ) {
                        Icon(
                            imageVector = if (hud.phase == RunPhase.PAUSED) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                            contentDescription = strings.paused,
                            tint = PureWhite
                        )
                    }
                }

                // Mode / Level + Shield pill
                Surface(
                    shape = RoundedCornerShape(50),
                    color = NeonSurface.copy(alpha = 0.75f),
                    border = BorderStroke(1.dp, accent.copy(alpha = 0.35f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val modeText = when (hud.mode) {
                            GameMode.CLASSIC -> strings.classicLabel
                            GameMode.ENDLESS -> strings.endlessLabel
                            GameMode.LEVELS -> "${strings.levelLabel} ${hud.levelNumber} • ${strings.target} ${hud.targetMilestone}"
                        }
                        Text(
                            text = modeText,
                            style = MaterialTheme.typography.labelSmall,
                            color = PureWhite
                        )
                        Icon(
                            imageVector = Icons.Rounded.Shield,
                            contentDescription = null,
                            tint = if (hud.hasShield) NeonEmerald else MutedText.copy(alpha = 0.35f),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Auto / Manual toggle
                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (hud.autoMode) accent.copy(alpha = 0.24f) else NeonSurface.copy(alpha = 0.78f),
                    border = BorderStroke(
                        1.dp,
                        if (hud.autoMode) accent else Color.White.copy(alpha = 0.22f)
                    ),
                    onClick = onToggleAuto,
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("game_auto_toggle")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (hud.autoMode) Icons.Rounded.SmartToy else Icons.Rounded.TouchApp,
                            contentDescription = strings.autoMode,
                            tint = if (hud.autoMode) accent else PureWhite,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Text(
                            text = if (hud.autoMode) strings.autoMode else strings.manualMode,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (hud.autoMode) accent else PureWhite
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Giant Crisp White Power-of-2 Score above the rectangular arena
            Text(
                text = "${hud.scoreMilestone}",
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 58.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 2.sp
                ),
                color = PureWhite,
                modifier = Modifier
                    .scale(scoreScale.value)
                    .testTag("game_score_text")
            )

            // Thin milestone progress bar + combo/new record indicator
            LinearProgressIndicator(
                progress = { hud.milestoneProgress },
                modifier = Modifier
                    .width(140.dp)
                    .height(3.dp)
                    .clip(RoundedCornerShape(50)),
                color = accent,
                trackColor = Color.White.copy(alpha = 0.14f)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (hud.isNewRecord) {
                    Text(
                        text = strings.newRecord,
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonGold
                    )
                }
                if (hud.combo > 1) {
                    Text(
                        text = "x${hud.combo} ${strings.combo}",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonCyan
                    )
                }
                Text(
                    text = "+${hud.earnedShards}",
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonMagenta
                )
            }
        }

        // Ready Hint Overlay (does not block touch on NeonArenaView below; wait: we keep pointer-transparent!)
        if (hud.phase == RunPhase.READY) {
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 26.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = strings.tapToLaunch,
                    style = MaterialTheme.typography.titleMedium.copy(letterSpacing = 2.sp),
                    color = PureWhite
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = strings.gestureHint,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedText,
                    textAlign = TextAlign.Center
                )
            }
        }

        // Pause Modal
        AnimatedVisibility(
            visible = hud.phase == RunPhase.PAUSED,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            OverlayCard(
                title = strings.paused,
                accentColor = accent
            ) {
                Button(
                    onClick = onTogglePause,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("pause_resume_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Color.Black)
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.resume, style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = onRestart,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("pause_restart_button"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.28f))
                ) {
                    Icon(Icons.Rounded.Refresh, contentDescription = null, tint = PureWhite)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.restart, color = PureWhite)
                }
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = onExitToMenu,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("pause_menu_button"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
                ) {
                    Icon(Icons.Rounded.Home, contentDescription = null, tint = MutedText)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.mainMenu, color = MutedText)
                }
            }
        }

        // Game Over / Level Complete Modal
        AnimatedVisibility(
            visible = hud.phase == RunPhase.GAME_OVER || hud.phase == RunPhase.LEVEL_COMPLETE,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            val isWin = hud.phase == RunPhase.LEVEL_COMPLETE
            OverlayCard(
                title = if (isWin) strings.levelComplete else strings.gameOver,
                accentColor = if (isWin) NeonEmerald else NeonMagenta
            ) {
                if (isWin) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        repeat(3) { idx ->
                            Icon(
                                imageVector = Icons.Rounded.Star,
                                contentDescription = null,
                                tint = if (idx < hud.starsEarned) NeonGold else Color.White.copy(alpha = 0.16f),
                                modifier = Modifier.size(34.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                } else if (hud.isNewRecord) {
                    Text(
                        text = strings.newRecord,
                        style = MaterialTheme.typography.labelLarge,
                        color = NeonGold
                    )
                    Spacer(Modifier.height(6.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    StatColumn(label = strings.score, value = "${hud.scoreMilestone}", valueColor = PureWhite)
                    StatColumn(label = strings.bounces, value = "${hud.bounces}", valueColor = NeonCyan)
                    StatColumn(
                        label = strings.shards,
                        value = "+${hud.earnedShards}",
                        valueColor = NeonGold,
                        showBolt = true
                    )
                }

                Spacer(Modifier.height(18.dp))

                if (isWin && hud.levelNumber < 50) {
                    Button(
                        onClick = onNextLevel,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("result_next_level_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald, contentColor = Color.Black)
                    ) {
                        Text(strings.nextLevel, style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.width(8.dp))
                        Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null)
                    }
                    Spacer(Modifier.height(10.dp))
                }

                Button(
                    onClick = onRestart,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("result_restart_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isWin) NeonSurface else accent,
                        contentColor = if (isWin) PureWhite else Color.Black
                    )
                ) {
                    Icon(Icons.Rounded.Refresh, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.restart, style = MaterialTheme.typography.titleMedium)
                }

                Spacer(Modifier.height(10.dp))

                OutlinedButton(
                    onClick = onExitToMenu,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("result_menu_button"),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.22f))
                ) {
                    Icon(Icons.Rounded.Home, contentDescription = null, tint = MutedText)
                    Spacer(Modifier.width(8.dp))
                    Text(strings.mainMenu, color = MutedText)
                }
            }
        }
    }
}

@Composable
private fun OverlayCard(
    title: String,
    accentColor: Color,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = Modifier
            .widthIn(max = 360.dp)
            .fillMaxWidth(0.88f),
        shape = RoundedCornerShape(24.dp),
        color = NeonSurface.copy(alpha = 0.94f),
        border = BorderStroke(1.5.dp, accentColor.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier.padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium,
                color = accentColor,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            content()
        }
    }
}

@Composable
private fun StatColumn(
    label: String,
    value: String,
    valueColor: Color,
    showBolt: Boolean = false
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MutedText
        )
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (showBolt) {
                Icon(
                    imageVector = Icons.Rounded.Bolt,
                    contentDescription = null,
                    tint = valueColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                color = valueColor
            )
        }
    }
}
