package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AllInclusive
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CardGiftcard
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.GameStrings
import com.example.model.AppState
import com.example.ui.theme.MutedText
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonGold
import com.example.ui.theme.NeonMagenta
import com.example.ui.theme.NeonSurface
import com.example.ui.theme.PureWhite

@Composable
fun MainMenuScreen(
    appState: AppState,
    strings: GameStrings,
    onPlay: () -> Unit,
    onLevels: () -> Unit,
    onEndless: () -> Unit,
    onSkins: () -> Unit,
    onRecords: () -> Unit,
    onSettings: () -> Unit,
    onClaimDaily: () -> Unit
) {
    val pulseTransition = rememberInfiniteTransition(label = "menu_pulse")
    val glowAlpha by pulseTransition.animateFloat(
        initialValue = 0.65f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow_alpha"
    )

    val accent = MaterialTheme.colorScheme.primary
    val secondary = MaterialTheme.colorScheme.secondary

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xBB000000),
                        Color(0x66000000),
                        Color(0xCC000000)
                    )
                )
            )
            .safeDrawingPadding()
            .padding(horizontal = 20.dp, vertical = 14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 520.dp)
                .align(Alignment.Center)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top bar: Energy Shards + Daily Reward Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = NeonSurface.copy(alpha = 0.85f),
                    border = BorderStroke(1.dp, accent.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Bolt,
                            contentDescription = strings.shards,
                            tint = NeonCyan,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${appState.progress.shards}",
                            style = MaterialTheme.typography.labelLarge,
                            color = PureWhite
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (appState.canClaimDailyReward) {
                        NeonMagenta.copy(alpha = 0.22f)
                    } else {
                        NeonSurface.copy(alpha = 0.78f)
                    },
                    border = BorderStroke(
                        1.dp,
                        if (appState.canClaimDailyReward) NeonGold.copy(alpha = glowAlpha) else Color.White.copy(alpha = 0.16f)
                    ),
                    modifier = Modifier
                        .testTag("daily_reward_pill")
                        .clickable(enabled = appState.canClaimDailyReward, onClick = onClaimDaily)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CardGiftcard,
                            contentDescription = strings.dailyReward,
                            tint = if (appState.canClaimDailyReward) NeonGold else MutedText,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (appState.canClaimDailyReward) {
                                "+${appState.nextDailyRewardAmount}"
                            } else {
                                strings.claimedToday
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (appState.canClaimDailyReward) NeonGold else MutedText
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(0.55f))

            // Brand Header
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(vertical = 12.dp)
            ) {
                Text(
                    text = strings.appTitle,
                    style = MaterialTheme.typography.displayLarge.copy(
                        fontSize = 42.sp,
                        letterSpacing = 5.sp
                    ),
                    color = PureWhite,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.alpha(glowAlpha)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = strings.developer,
                    style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 4.sp),
                    color = accent,
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.weight(0.55f))

            // Primary PLAY button
            Button(
                onClick = onPlay,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(62.dp)
                    .shadow(16.dp, RoundedCornerShape(18.dp), ambientColor = accent, spotColor = accent)
                    .testTag("menu_play_button"),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = accent,
                    contentColor = Color.Black
                )
            ) {
                Icon(
                    imageVector = Icons.Rounded.PlayArrow,
                    contentDescription = strings.play,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = strings.play,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 2.5.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Mode Row: LEVELS + ENDLESS
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MenuActionCard(
                    title = strings.levels,
                    subtitle = "${appState.progress.highestUnlockedLevel}/50",
                    icon = Icons.Rounded.GridView,
                    accentColor = secondary,
                    testTag = "menu_levels_button",
                    modifier = Modifier.weight(1f),
                    onClick = onLevels
                )
                MenuActionCard(
                    title = strings.endless,
                    subtitle = "${strings.best}: ${appState.progress.bestEndlessScore.coerceAtLeast(1)}",
                    icon = Icons.Rounded.AllInclusive,
                    accentColor = NeonCyan,
                    testTag = "menu_endless_button",
                    modifier = Modifier.weight(1f),
                    onClick = onEndless
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Secondary Row: SKINS + RECORDS + SETTINGS
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MenuCompactTile(
                    title = strings.skins,
                    icon = Icons.Rounded.Palette,
                    accentColor = NeonMagenta,
                    testTag = "menu_skins_button",
                    modifier = Modifier.weight(1f),
                    onClick = onSkins
                )
                MenuCompactTile(
                    title = strings.records,
                    icon = Icons.Rounded.EmojiEvents,
                    accentColor = NeonGold,
                    testTag = "menu_records_button",
                    modifier = Modifier.weight(1f),
                    onClick = onRecords
                )
                MenuCompactTile(
                    title = strings.settings,
                    icon = Icons.Rounded.Settings,
                    accentColor = accent,
                    testTag = "menu_settings_button",
                    modifier = Modifier.weight(1f),
                    onClick = onSettings
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Best Classic footer pill
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    tint = accent.copy(alpha = 0.8f),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${strings.bestClassic}: ${appState.progress.bestClassicScore.coerceAtLeast(1)}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedText
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
private fun MenuActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    testTag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier
            .height(74.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(1.2.dp, accentColor.copy(alpha = 0.7f)),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = NeonSurface.copy(alpha = 0.82f),
            contentColor = PureWhite
        )
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.4.sp
                    ),
                    color = PureWhite
                )
            }
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MutedText
            )
        }
    }
}

@Composable
private fun MenuCompactTile(
    title: String,
    icon: ImageVector,
    accentColor: Color,
    testTag: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier
            .height(66.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = NeonSurface.copy(alpha = 0.78f),
            contentColor = PureWhite
        ),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 6.dp, vertical = 8.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = accentColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 0.8.sp),
                color = PureWhite,
                maxLines = 1
            )
        }
    }
}
