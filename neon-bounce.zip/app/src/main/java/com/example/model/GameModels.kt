package com.example.model

enum class AppLanguage(val code: String, val nativeLabel: String) {
    RU("ru", "Русский"),
    EN("en", "English"),
    TJ("tj", "Тоҷикӣ")
}

enum class GraphicsQuality(
    val lineCount: Int,
    val waveSegments: Int,
    val enableBlur: Boolean,
    val particleFactor: Float
) {
    LOW(lineCount = 90, waveSegments = 24, enableBlur = false, particleFactor = 0.5f),
    MEDIUM(lineCount = 155, waveSegments = 32, enableBlur = false, particleFactor = 0.85f),
    HIGH(lineCount = 225, waveSegments = 40, enableBlur = true, particleFactor = 1.0f),
    ULTRA(lineCount = 300, waveSegments = 48, enableBlur = true, particleFactor = 1.4f)
}

enum class TargetFps(val fps: Int) {
    FPS_30(30),
    FPS_60(60),
    FPS_120(120)
}

enum class GameMode {
    CLASSIC,
    LEVELS,
    ENDLESS
}

enum class ScreenRoute {
    MENU,
    GAME,
    LEVELS,
    SHOP,
    RECORDS,
    SETTINGS
}

enum class BallRenderStyle {
    CORE_GLOW,
    PRISM_RING,
    PLASMA_ORB,
    QUANTUM_CROSS,
    NOVA_STAR,
    CYBER_DUAL
}

enum class TrailRenderMode {
    SMOOTH_RIBBON,
    COMET_SPARKS,
    DOUBLE_HELIX,
    LASER_GHOST,
    PRISM_RAIN,
    PULSE_RINGS
}

data class BallSkin(
    val id: String,
    val nameKey: String,
    val cost: Int,
    val primaryColor: Long,
    val secondaryColor: Long,
    val coreColor: Long,
    val style: BallRenderStyle
)

data class TrailSkin(
    val id: String,
    val nameKey: String,
    val cost: Int,
    val mode: TrailRenderMode,
    val accentColor: Long
)

data class ArenaTheme(
    val id: String,
    val nameKey: String,
    val cost: Int,
    val palette: List<Long>,
    val borderColor: Long
)

data class LevelConfig(
    val number: Int,
    val targetMilestone: Int,
    val requiredBounces: Int,
    val speedMultiplier: Float,
    val waveTurbulence: Float,
    val hazardCount: Int,
    val harmonicNodes: Int,
    val rewardShards: Int
)

data class GameSettings(
    val musicEnabled: Boolean = true,
    val soundEnabled: Boolean = true,
    val vibrationEnabled: Boolean = true,
    val graphicsQuality: GraphicsQuality = GraphicsQuality.HIGH,
    val targetFps: TargetFps = TargetFps.FPS_60,
    val language: AppLanguage = AppLanguage.RU,
    val selectedThemeId: String = "cyber_spectrum"
)

data class GameProgress(
    val shards: Int = 120,
    val bestClassicScore: Int = 0,
    val bestEndlessScore: Int = 0,
    val highestMilestone: Int = 1,
    val totalBounces: Long = 0L,
    val totalGamesPlayed: Int = 0,
    val highestUnlockedLevel: Int = 1,
    val levelStars: Map<Int, Int> = emptyMap(),
    val unlockedBallIds: Set<String> = setOf("classic_cyan"),
    val unlockedTrailIds: Set<String> = setOf("smooth_ribbon"),
    val unlockedThemeIds: Set<String> = setOf("cyber_spectrum"),
    val equippedBallId: String = "classic_cyan",
    val equippedTrailId: String = "smooth_ribbon",
    val dailyStreak: Int = 0,
    val lastDailyClaimDay: Long = -1L,
    val milestoneHistory: List<Int> = emptyList()
)

data class AppState(
    val settings: GameSettings = GameSettings(),
    val progress: GameProgress = GameProgress(),
    val canClaimDailyReward: Boolean = true,
    val nextDailyRewardAmount: Int = 75
)

object GameCatalog {
    val milestoneSequence: List<Int> = listOf(
        1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192
    )

    val ballSkins: List<BallSkin> = listOf(
        BallSkin("classic_cyan", "skin_cyan", 0, 0xFF00F0FF, 0xFF7B2CBF, 0xFFFFFFFF, BallRenderStyle.CORE_GLOW),
        BallSkin("plasma_rose", "skin_rose", 80, 0xFFFF2E93, 0xFF00E5FF, 0xFFFFFFFF, BallRenderStyle.PLASMA_ORB),
        BallSkin("emerald_pulse", "skin_emerald", 120, 0xFF00FF87, 0xFF00B4D8, 0xFFFFFFFF, BallRenderStyle.CORE_GLOW),
        BallSkin("solar_flare", "skin_solar", 180, 0xFFFFD60A, 0xFFFF5400, 0xFFFFFFFF, BallRenderStyle.NOVA_STAR),
        BallSkin("quantum_ring", "skin_quantum", 250, 0xFF9D4EDD, 0xFF00F5D4, 0xFFFFFFFF, BallRenderStyle.PRISM_RING),
        BallSkin("cyber_dual", "skin_cyber", 320, 0xFF00BBF9, 0xFFF15BB5, 0xFFFFFFFF, BallRenderStyle.CYBER_DUAL),
        BallSkin("hyper_cross", "skin_hyper", 420, 0xFF38B000, 0xFFFFE600, 0xFFFFFFFF, BallRenderStyle.QUANTUM_CROSS),
        BallSkin("prism_nova", "skin_prism", 600, 0xFFFF006E, 0xFF3A86FF, 0xFFFFFFFF, BallRenderStyle.NOVA_STAR)
    )

    val trailSkins: List<TrailSkin> = listOf(
        TrailSkin("smooth_ribbon", "trail_ribbon", 0, TrailRenderMode.SMOOTH_RIBBON, 0xFF00F0FF),
        TrailSkin("comet_sparks", "trail_sparks", 90, TrailRenderMode.COMET_SPARKS, 0xFFFF2E93),
        TrailSkin("double_helix", "trail_helix", 160, TrailRenderMode.DOUBLE_HELIX, 0xFF9D4EDD),
        TrailSkin("laser_ghost", "trail_ghost", 220, TrailRenderMode.LASER_GHOST, 0xFF00FF87),
        TrailSkin("prism_rain", "trail_prism", 300, TrailRenderMode.PRISM_RAIN, 0xFFFFD60A),
        TrailSkin("pulse_rings", "trail_rings", 400, TrailRenderMode.PULSE_RINGS, 0xFF00BBF9)
    )

    val arenaThemes: List<ArenaTheme> = listOf(
        ArenaTheme(
            id = "cyber_spectrum",
            nameKey = "theme_spectrum",
            cost = 0,
            palette = listOf(0xFF0088FF, 0xFF00F0FF, 0xFF9D4EDD, 0xFFFF2E93, 0xFF00FF87, 0xFFFFE600),
            borderColor = 0xFF00E5FF
        ),
        ArenaTheme(
            id = "electric_ocean",
            nameKey = "theme_ocean",
            cost = 100,
            palette = listOf(0xFF0077B6, 0xFF00B4D8, 0xFF00F5D4, 0xFF48CAE4, 0xFF90E0EF, 0xFF4CC9F0),
            borderColor = 0xFF00F5D4
        ),
        ArenaTheme(
            id = "synth_magenta",
            nameKey = "theme_synth",
            cost = 150,
            palette = listOf(0xFF7209B7, 0xFFB5179E, 0xFFF72585, 0xFF4361EE, 0xFF4CC9F0, 0xFFFF9E00),
            borderColor = 0xFFF72585
        ),
        ArenaTheme(
            id = "emerald_matrix",
            nameKey = "theme_matrix",
            cost = 200,
            palette = listOf(0xFF006400, 0xFF00AA55, 0xFF00FF87, 0xFF70E000, 0xFFCCFF33, 0xFF00E5FF),
            borderColor = 0xFF00FF87
        ),
        ArenaTheme(
            id = "solar_eclipse",
            nameKey = "theme_solar",
            cost = 280,
            palette = listOf(0xFFFF4800, 0xFFFF7900, 0xFFFFB700, 0xFFFFE600, 0xFFFF2E93, 0xFF9D4EDD),
            borderColor = 0xFFFFB700
        )
    )

    val levels: List<LevelConfig> = (1..50).map { lvl ->
        val tierIndex = when {
            lvl <= 3 -> 3   // 8
            lvl <= 7 -> 4   // 16
            lvl <= 12 -> 5  // 32
            lvl <= 18 -> 6  // 64
            lvl <= 24 -> 7  // 128
            lvl <= 30 -> 8  // 256
            lvl <= 36 -> 9  // 512
            lvl <= 42 -> 10 // 1024
            lvl <= 46 -> 11 // 2048
            lvl <= 49 -> 12 // 4096
            else -> 13      // 8192
        }
        val targetMilestone = milestoneSequence[tierIndex]
        val requiredBounces = 6 + (lvl * 1.4f).toInt()
        val speedMultiplier = 0.88f + (lvl - 1) * 0.024f
        val turbulence = 0.4f + (lvl - 1) * 0.025f
        val hazards = when {
            lvl < 5 -> 0
            lvl < 15 -> 1
            lvl < 30 -> 2
            lvl < 42 -> 3
            else -> 4
        }
        val harmonicNodes = if (lvl < 10) 1 else if (lvl < 30) 2 else 3
        val reward = 20 + lvl * 5
        LevelConfig(
            number = lvl,
            targetMilestone = targetMilestone,
            requiredBounces = requiredBounces,
            speedMultiplier = speedMultiplier,
            waveTurbulence = turbulence,
            hazardCount = hazards,
            harmonicNodes = harmonicNodes,
            rewardShards = reward
        )
    }

    fun getBallSkin(id: String): BallSkin =
        ballSkins.firstOrNull { it.id == id } ?: ballSkins.first()

    fun getTrailSkin(id: String): TrailSkin =
        trailSkins.firstOrNull { it.id == id } ?: trailSkins.first()

    fun getArenaTheme(id: String): ArenaTheme =
        arenaThemes.firstOrNull { it.id == id } ?: arenaThemes.first()
}
