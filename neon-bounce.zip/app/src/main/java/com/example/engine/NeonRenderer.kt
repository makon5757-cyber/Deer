package com.example.engine

import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import com.example.model.ArenaTheme
import com.example.model.BallRenderStyle
import com.example.model.BallSkin
import com.example.model.GraphicsQuality
import com.example.model.TrailRenderMode
import com.example.model.TrailSkin
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class NeonRenderer {

    private var currentQuality: GraphicsQuality = GraphicsQuality.HIGH
    private var maxSegments: Int = currentQuality.waveSegments
    private var waveYs = FloatArray(maxSegments + 1)

    // Pre-allocated pulse caches to eliminate per-line overhead
    private val activePulseCountMax = NeonPhysicsEngine.PULSE_POOL_SIZE
    private val activePX = FloatArray(activePulseCountMax)
    private val activePY = FloatArray(activePulseCountMax)
    private val activePR = FloatArray(activePulseCountMax)
    private val activePStrengthFade = FloatArray(activePulseCountMax)
    private val activePAge = FloatArray(activePulseCountMax)
    private val lineActivePulseIndices = IntArray(activePulseCountMax)

    private val wavePath = Path()
    private val ribbonPath = Path()
    private val arenaRect = RectF()

    private var softBlur: BlurMaskFilter? = BlurMaskFilter(12f, BlurMaskFilter.Blur.NORMAL)
    private var ballBlur: BlurMaskFilter? = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL)

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.BLACK
    }

    private val arenaFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val lineCorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val lineGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val borderGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val borderCorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.8f
        color = Color.WHITE
    }

    private val ballPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val ballStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val trailPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    private val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val pulseRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }

    private var cachedHeight: Float = -1f
    private var cachedWidth: Float = -1f

    fun configureQuality(quality: GraphicsQuality) {
        if (currentQuality != quality) {
            currentQuality = quality
            maxSegments = quality.waveSegments
            waveYs = FloatArray(maxSegments + 1)
            if (quality.enableBlur) {
                softBlur = BlurMaskFilter(10f, BlurMaskFilter.Blur.NORMAL)
                ballBlur = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL)
            } else {
                softBlur = null
                ballBlur = null
            }
        }
    }

    fun render(
        canvas: Canvas,
        width: Float,
        height: Float,
        engine: NeonPhysicsEngine,
        ballSkin: BallSkin,
        trailSkin: TrailSkin,
        theme: ArenaTheme,
        arenaBoundsOut: RectF
    ) {
        // Pure pitch-black background
        canvas.drawRect(0f, 0f, width, height, bgPaint)

        // Compute centered vertical rectangular arena leaving room at top for giant white score
        val isCompactWidth = width < height * 0.85f
        val topReserved = if (isCompactWidth) height * 0.21f else height * 0.19f
        val bottomReserved = height * 0.08f
        val availHeight = (height - topReserved - bottomReserved).coerceAtLeast(240f)
        val desiredRatio = 0.64f // Vertical 9:14 arena proportions
        val maxArenaWidth = width * 0.84f
        val arenaW = min(maxArenaWidth, availHeight * desiredRatio)
        val arenaH = min(availHeight, arenaW / desiredRatio)

        val shakeX = if (engine.shakeIntensity > 0.01f) {
            sin(engine.elapsedTime * 68f) * engine.shakeIntensity * 8f
        } else 0f
        val shakeY = if (engine.shakeIntensity > 0.01f) {
            cos(engine.elapsedTime * 57f) * engine.shakeIntensity * 7f
        } else 0f

        val camX = engine.cameraOffsetX * arenaW + shakeX
        val camY = engine.cameraOffsetY * arenaH + shakeY

        val left = (width - arenaW) * 0.5f + camX
        val top = topReserved + (availHeight - arenaH) * 0.38f + camY
        val right = left + arenaW
        val bottom = top + arenaH

        arenaRect.set(left, top, right, bottom)
        arenaBoundsOut.set(arenaRect)

        // Subtle dark interior gradient inside arena
        if (cachedWidth != width || cachedHeight != height) {
            cachedWidth = width
            cachedHeight = height
            arenaFillPaint.shader = LinearGradient(
                0f, top, 0f, bottom,
                intArrayOf(0xFF03050C.toInt(), 0xFF000000.toInt(), 0xFF040712.toInt()),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(arenaRect, arenaFillPaint)

        // Milestone / record light flash across arena
        if (engine.flashAlpha > 0.01f) {
            val flashColor = adjustAlpha(engine.currentColor(), engine.flashAlpha * 0.22f)
            particlePaint.color = flashColor
            canvas.drawRect(arenaRect, particlePaint)
        }

        val saveCount = canvas.save()
        canvas.clipRect(arenaRect)

        // 1. Render hundreds of dynamic horizontal neon wave lines
        drawWaveField(canvas, arenaRect, engine, theme)

        // 2. Render active harmonic wave targets & bottom player catcher wave highlight
        drawHarmonicAndCatcherHighlights(canvas, arenaRect, engine, theme)

        // 3. Render Void Hazards (if any in level/endless)
        drawVoidHazards(canvas, arenaRect, engine)

        // 4. Render expanding wave burst rings & sparks
        drawPulsesAndSparks(canvas, arenaRect, engine)

        // 5. Render long fading ball trail
        drawBallTrail(canvas, arenaRect, engine, ballSkin, trailSkin)

        // 6. Render neon ball with bright core & glow
        drawNeonBall(canvas, arenaRect, engine, ballSkin)

        canvas.restoreToCount(saveCount)

        // 7. Render thin luminous arena borders + impact flares
        drawArenaBorders(canvas, arenaRect, engine, theme)
    }

    private fun drawWaveField(
        canvas: Canvas,
        rect: RectF,
        engine: NeonPhysicsEngine,
        theme: ArenaTheme
    ) {
        val lineCount = currentQuality.lineCount
        val segs = maxSegments
        val palette = theme.palette
        val paletteSize = palette.size

        val w = rect.width()
        val h = rect.height()
        val dx = w / segs
        val t = engine.elapsedTime

        val ballX = engine.ballX
        val ballY = engine.ballY
        val ptrActive = engine.pointerActive && engine.phase == RunPhase.PLAYING
        val ptrX = engine.pointerX
        val ptrY = engine.pointerY

        lineCorePaint.maskFilter = null
        lineGlowPaint.maskFilter = if (currentQuality.enableBlur) softBlur else null

        var activePulseCount = 0
        for (p in engine.pulses) {
            if (!p.active) continue
            activePX[activePulseCount] = p.x
            activePY[activePulseCount] = p.y
            activePR[activePulseCount] = p.radius
            activePStrengthFade[activePulseCount] = (1f - p.age / p.duration) * p.strength * 0.034f
            activePAge[activePulseCount] = p.age * 14f
            activePulseCount++
        }

        for (i in 0 until lineCount) {
            val ny = 0.03f + (i.toFloat() / (lineCount - 1).coerceAtLeast(1)) * 0.94f
            val baseY = rect.top + ny * h

            // Determine neon spectrum color for this line + chromatic shift
            val colorPos = ((ny * paletteSize + engine.colorHueShift * paletteSize + engine.tierIndex * 0.65f) % paletteSize + paletteSize) % paletteSize
            val cIdx0 = colorPos.toInt() % paletteSize
            val cIdx1 = (cIdx0 + 1) % paletteSize
            val frac = colorPos - colorPos.toInt()
            val lineColor = lerpColor(palette[cIdx0].toInt(), palette[cIdx1].toInt(), frac)

            // Proximity boost near ball or catcher wave
            val distBallY = abs(ny - ballY)
            val ballProx = exp(-distBallY * distBallY * 42f)
            val catcherProx = exp(-(ny - engine.catcherY) * (ny - engine.catcherY) * 140f)
            val energyHighlight = max(ballProx, catcherProx)

            val alpha = (0.34f + energyHighlight * 0.56f).coerceIn(0.22f, 0.95f)
            lineCorePaint.color = adjustAlpha(lineColor, alpha)
            lineCorePaint.strokeWidth = 1.25f + energyHighlight * 1.35f

            var linePulseCount = 0
            for (ap in 0 until activePulseCount) {
                if (abs(ny - activePY[ap]) < activePR[ap] + 0.14f) {
                    lineActivePulseIndices[linePulseCount++] = ap
                }
            }

            // Build deformed wave points along X
            for (s in 0..segs) {
                val nx = s.toFloat() / segs
                var dispNorm = 0f

                // Ambient traveling harmonic waves
                dispNorm += sin(nx * 7.5f + t * 2.1f + ny * 11f) * 0.0055f
                dispNorm += cos(nx * 14f - t * 1.6f + ny * 6f) * 0.0028f

                // Ball magnetic V/U deflection
                val dxb = nx - ballX
                val dyb = ny - ballY
                val distSqB = dxb * dxb + dyb * dyb
                if (distSqB < 0.09f) {
                    val influence = exp(-distSqB * 36f)
                    val pushDir = if (dyb >= 0f) 1f else -1f
                    // Creates crisp V/U bend around the ball!
                    dispNorm += pushDir * influence * 0.038f
                }

                // Player hold tension well (deep U/V slingshot bend)
                if (ptrActive) {
                    val dxp = nx - ptrX
                    val dyp = ny - ptrY
                    val distSqP = dxp * dxp + dyp * dyp
                    if (distSqP < 0.14f) {
                        val influence = exp(-distSqP * 24f)
                        dispNorm += influence * 0.052f
                    }
                }

                // Catcher wave trampoline U-dip on impact
                if (abs(ny - engine.catcherY) < 0.10f) {
                    val dxc = nx - engine.catcherBendX
                    val catInfluence = exp(-dxc * dxc * 28f) * exp(-(ny - engine.catcherY) * (ny - engine.catcherY) * 160f)
                    dispNorm += catInfluence * engine.catcherBend * 0.065f
                }

                // Active wave collision shockwaves propagating across the strings
                for (lp in 0 until linePulseCount) {
                    val ap = lineActivePulseIndices[lp]
                    val px = nx - activePX[ap]
                    val py = ny - activePY[ap]
                    val d = sqrt(px * px + py * py)
                    val ringDiff = d - activePR[ap]
                    if (abs(ringDiff) < 0.14f) {
                        val waveEnv = exp(-ringDiff * ringDiff * 180f) * activePStrengthFade[ap]
                        dispNorm += sin(ringDiff * 48f - activePAge[ap]) * waveEnv
                    }
                }

                waveYs[s] = baseY + dispNorm * h
            }

            wavePath.reset()
            wavePath.moveTo(rect.left, waveYs[0])
            for (s in 1..segs) {
                wavePath.lineTo(rect.left + s * dx, waveYs[s])
            }

            // Draw soft outer neon aura on highlighted bands or every 4th line for high-speed glow
            if (energyHighlight > 0.25f || (currentQuality != GraphicsQuality.LOW && i % 5 == 0)) {
                lineGlowPaint.color = adjustAlpha(lineColor, (0.14f + energyHighlight * 0.28f).coerceAtMost(0.45f))
                lineGlowPaint.strokeWidth = 4.2f + energyHighlight * 4.5f
                canvas.drawPath(wavePath, lineGlowPaint)
            }

            canvas.drawPath(wavePath, lineCorePaint)
        }
    }

    private fun drawHarmonicAndCatcherHighlights(
        canvas: Canvas,
        rect: RectF,
        engine: NeonPhysicsEngine,
        theme: ArenaTheme
    ) {
        val w = rect.width()
        val h = rect.height()

        // Mid-arena glowing harmonic wave bands
        for ((idx, band) in engine.harmonicBands.withIndex()) {
            val col = theme.palette[(idx + engine.tierIndex + 2) % theme.palette.size].toInt()
            val startX = rect.left + (band.xCenter - band.halfWidth) * w
            val endX = rect.left + (band.xCenter + band.halfWidth) * w
            val baseY = rect.top + band.y * h

            wavePath.reset()
            val steps = 18
            for (s in 0..steps) {
                val frac = s.toFloat() / steps
                val px = startX + (endX - startX) * frac
                val arch = sin(frac * PI.toFloat())
                val bend = arch * band.bendImpulse * 0.045f * h + sin(frac * 6f + band.phase) * 4f
                val py = baseY + bend
                if (s == 0) wavePath.moveTo(px, py) else wavePath.lineTo(px, py)
            }

            lineGlowPaint.maskFilter = softBlur
            lineGlowPaint.color = adjustAlpha(col, 0.45f)
            lineGlowPaint.strokeWidth = 10f
            canvas.drawPath(wavePath, lineGlowPaint)

            lineCorePaint.color = Color.WHITE
            lineCorePaint.strokeWidth = 3f
            canvas.drawPath(wavePath, lineCorePaint)
        }

        // Player Catcher Wave String near bottom (when not in pure menu demo)
        if (engine.phase != RunPhase.MENU_DEMO) {
            val cx = rect.left + engine.catcherX * w
            val cy = rect.top + engine.catcherY * h
            val hw = engine.catcherHalfWidth * w
            val catcherColor = if (engine.hasShield) engine.currentColor() else 0xFFFF2E93.toInt()

            wavePath.reset()
            val steps = 22
            for (s in 0..steps) {
                val frac = s.toFloat() / steps
                val rel = frac * 2f - 1f
                val px = cx + rel * hw
                val uCurve = (1f - rel * rel) * (8f + engine.catcherBend * 26f)
                val py = cy + uCurve
                if (s == 0) wavePath.moveTo(px, py) else wavePath.lineTo(px, py)
            }

            lineGlowPaint.maskFilter = softBlur
            lineGlowPaint.color = adjustAlpha(catcherColor, 0.55f)
            lineGlowPaint.strokeWidth = 13f
            canvas.drawPath(wavePath, lineGlowPaint)

            lineCorePaint.color = catcherColor
            lineCorePaint.strokeWidth = 5f
            canvas.drawPath(wavePath, lineCorePaint)

            lineCorePaint.color = Color.WHITE
            lineCorePaint.strokeWidth = 2.2f
            canvas.drawPath(wavePath, lineCorePaint)
        }
    }

    private fun drawVoidHazards(canvas: Canvas, rect: RectF, engine: NeonPhysicsEngine) {
        val w = rect.width()
        val h = rect.height()
        for (hazard in engine.hazards) {
            val hx = rect.left + hazard.x * w
            val hy = rect.top + hazard.y * h
            val hr = hazard.radius * w

            ballStrokePaint.maskFilter = softBlur
            ballStrokePaint.color = 0x99FF0055.toInt()
            ballStrokePaint.strokeWidth = 7f
            canvas.drawCircle(hx, hy, hr, ballStrokePaint)

            ballStrokePaint.maskFilter = null
            ballStrokePaint.color = 0xFFFF2E93.toInt()
            ballStrokePaint.strokeWidth = 2.8f
            canvas.drawCircle(hx, hy, hr, ballStrokePaint)

            ballPaint.shader = null
            ballPaint.maskFilter = null
            ballPaint.color = 0xFF1A0010.toInt()
            canvas.drawCircle(hx, hy, hr * 0.72f, ballPaint)

            // Rotating inner X cross
            val rot = engine.elapsedTime * 3.2f + hazard.phase
            val rIn = hr * 0.45f
            val c1 = cos(rot) * rIn
            val s1 = sin(rot) * rIn
            lineCorePaint.color = 0xFFFF5E99.toInt()
            lineCorePaint.strokeWidth = 2.4f
            canvas.drawLine(hx - c1, hy - s1, hx + c1, hy + s1, lineCorePaint)
            canvas.drawLine(hx + s1, hy - c1, hx - s1, hy + c1, lineCorePaint)
        }
    }

    private fun drawPulsesAndSparks(canvas: Canvas, rect: RectF, engine: NeonPhysicsEngine) {
        val w = rect.width()
        val h = rect.height()

        for (p in engine.pulses) {
            if (!p.active) continue
            val progress = (p.age / p.duration).coerceIn(0f, 1f)
            val alpha = (1f - progress) * 0.48f
            pulseRingPaint.color = adjustAlpha(p.colorArgb, alpha)
            pulseRingPaint.strokeWidth = (1f - progress) * 4.5f + 1f
            pulseRingPaint.maskFilter = if (currentQuality.enableBlur) softBlur else null
            canvas.drawCircle(
                rect.left + p.x * w,
                rect.top + p.y * h,
                p.radius * w,
                pulseRingPaint
            )
        }

        for (pt in engine.particles) {
            if (!pt.active) continue
            val alpha = (1f - pt.life / pt.maxLife).coerceIn(0f, 1f)
            particlePaint.color = adjustAlpha(pt.colorArgb, alpha)
            canvas.drawCircle(
                rect.left + pt.x * w,
                rect.top + pt.y * h,
                pt.size * alpha,
                particlePaint
            )
        }
    }

    private fun drawBallTrail(
        canvas: Canvas,
        rect: RectF,
        engine: NeonPhysicsEngine,
        ballSkin: BallSkin,
        trailSkin: TrailSkin
    ) {
        val w = rect.width()
        val h = rect.height()
        val cap = NeonPhysicsEngine.TRAIL_CAPACITY
        val head = engine.trailHead
        val ballRadiusPx = engine.ballRadius * w
        val baseCol = blendSkinColor(ballSkin, engine.currentColor())

        when (trailSkin.mode) {
            TrailRenderMode.SMOOTH_RIBBON, TrailRenderMode.LASER_GHOST -> {
                val widthFactor = if (trailSkin.mode == TrailRenderMode.LASER_GHOST) 0.55f else 1.0f
                var prevX = 0f
                var prevY = 0f
                var hasPrev = false

                for (k in 0 until cap) {
                    val idx = (head + k) % cap
                    val sample = engine.trailBuffer[idx]
                    if (!sample.active) continue

                    val t = k.toFloat() / cap
                    val sx = rect.left + sample.x * w
                    val sy = rect.top + sample.y * h

                    if (hasPrev) {
                        val segAlpha = t * t * 0.78f
                        val segWidth = (ballRadiusPx * 1.45f * t * widthFactor).coerceAtLeast(1.5f)
                        trailPaint.maskFilter = if (currentQuality.enableBlur && k % 2 == 0) softBlur else null
                        trailPaint.color = adjustAlpha(baseCol, segAlpha * 0.5f)
                        trailPaint.strokeWidth = segWidth * 1.65f
                        canvas.drawLine(prevX, prevY, sx, sy, trailPaint)

                        trailPaint.maskFilter = null
                        trailPaint.color = adjustAlpha(Color.WHITE, segAlpha * 0.65f)
                        trailPaint.strokeWidth = (segWidth * 0.48f).coerceAtLeast(1f)
                        canvas.drawLine(prevX, prevY, sx, sy, trailPaint)
                    }
                    prevX = sx
                    prevY = sy
                    hasPrev = true
                }
            }

            TrailRenderMode.COMET_SPARKS, TrailRenderMode.PRISM_RAIN -> {
                for (k in 0 until cap step 2) {
                    val idx = (head + k) % cap
                    val sample = engine.trailBuffer[idx]
                    if (!sample.active) continue
                    val t = k.toFloat() / cap
                    val sx = rect.left + sample.x * w
                    val sy = rect.top + sample.y * h
                    val col = if (trailSkin.mode == TrailRenderMode.PRISM_RAIN) {
                        Color.HSVToColor(floatArrayOf(((k * 9f + engine.elapsedTime * 140f) % 360f), 0.95f, 1f))
                    } else {
                        lerpColor(trailSkin.accentColor.toInt(), baseCol, t)
                    }
                    particlePaint.color = adjustAlpha(col, t * 0.85f)
                    canvas.drawCircle(sx, sy, (ballRadiusPx * 0.72f * t).coerceAtLeast(1.5f), particlePaint)
                }
            }

            TrailRenderMode.DOUBLE_HELIX -> {
                for (k in 0 until cap) {
                    val idx = (head + k) % cap
                    val sample = engine.trailBuffer[idx]
                    if (!sample.active) continue
                    val t = k.toFloat() / cap
                    val sx = rect.left + sample.x * w
                    val sy = rect.top + sample.y * h
                    val offset = sin(k * 0.45f + engine.elapsedTime * 12f) * ballRadiusPx * 0.8f * (1f - t * 0.4f)
                    particlePaint.color = adjustAlpha(baseCol, t * 0.75f)
                    canvas.drawCircle(sx + offset, sy, (ballRadiusPx * 0.36f * t).coerceAtLeast(1.5f), particlePaint)
                    particlePaint.color = adjustAlpha(ballSkin.secondaryColor.toInt(), t * 0.75f)
                    canvas.drawCircle(sx - offset, sy, (ballRadiusPx * 0.36f * t).coerceAtLeast(1.5f), particlePaint)
                }
            }

            TrailRenderMode.PULSE_RINGS -> {
                for (k in 0 until cap step 5) {
                    val idx = (head + k) % cap
                    val sample = engine.trailBuffer[idx]
                    if (!sample.active) continue
                    val t = k.toFloat() / cap
                    val sx = rect.left + sample.x * w
                    val sy = rect.top + sample.y * h
                    pulseRingPaint.maskFilter = null
                    pulseRingPaint.color = adjustAlpha(baseCol, t * 0.65f)
                    pulseRingPaint.strokeWidth = 2f
                    canvas.drawCircle(sx, sy, ballRadiusPx * (1.2f - t * 0.4f), pulseRingPaint)
                }
            }
        }
    }

    private fun drawNeonBall(
        canvas: Canvas,
        rect: RectF,
        engine: NeonPhysicsEngine,
        ballSkin: BallSkin
    ) {
        val bx = rect.left + engine.ballX * rect.width()
        val by = rect.top + engine.ballY * rect.height()
        val r = engine.ballRadius * rect.width()
        val primary = blendSkinColor(ballSkin, engine.currentColor())
        val secondary = ballSkin.secondaryColor.toInt()

        // Outer soft radial glow
        ballPaint.maskFilter = null
        ballPaint.shader = RadialGradient(
            bx, by, r * 3.2f,
            intArrayOf(adjustAlpha(primary, 0.72f), adjustAlpha(secondary, 0.22f), Color.TRANSPARENT),
            floatArrayOf(0f, 0.45f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(bx, by, r * 3.2f, ballPaint)
        ballPaint.shader = null

        // Ball body
        ballPaint.maskFilter = if (currentQuality.enableBlur) ballBlur else null
        ballPaint.color = primary
        canvas.drawCircle(bx, by, r * 1.08f, ballPaint)

        // Skin-specific detailing
        ballPaint.maskFilter = null
        when (ballSkin.style) {
            BallRenderStyle.PRISM_RING -> {
                ballStrokePaint.maskFilter = null
                ballStrokePaint.color = secondary
                ballStrokePaint.strokeWidth = 3.2f
                canvas.drawCircle(bx, by, r * 1.45f, ballStrokePaint)
            }
            BallRenderStyle.CYBER_DUAL -> {
                ballStrokePaint.maskFilter = null
                ballStrokePaint.color = secondary
                ballStrokePaint.strokeWidth = 3f
                val angle = engine.elapsedTime * 180f
                canvas.drawArc(bx - r * 1.35f, by - r * 1.35f, bx + r * 1.35f, by + r * 1.35f, angle, 140f, false, ballStrokePaint)
                canvas.drawArc(bx - r * 1.35f, by - r * 1.35f, bx + r * 1.35f, by + r * 1.35f, angle + 180f, 140f, false, ballStrokePaint)
            }
            BallRenderStyle.QUANTUM_CROSS -> {
                val rot = engine.elapsedTime * 2.8f
                val len = r * 1.6f
                lineCorePaint.color = secondary
                lineCorePaint.strokeWidth = 2.5f
                canvas.drawLine(bx - cos(rot) * len, by - sin(rot) * len, bx + cos(rot) * len, by + sin(rot) * len, lineCorePaint)
                canvas.drawLine(bx + sin(rot) * len, by - cos(rot) * len, bx - sin(rot) * len, by + cos(rot) * len, lineCorePaint)
            }
            BallRenderStyle.NOVA_STAR -> {
                ballStrokePaint.maskFilter = null
                ballStrokePaint.color = adjustAlpha(secondary, 0.75f)
                ballStrokePaint.strokeWidth = 2.2f
                canvas.drawCircle(bx, by, r * (1.3f + 0.15f * sin(engine.elapsedTime * 8f)), ballStrokePaint)
            }
            BallRenderStyle.PLASMA_ORB -> {
                ballPaint.color = adjustAlpha(secondary, 0.55f)
                canvas.drawCircle(bx + sin(engine.elapsedTime * 7f) * r * 0.2f, by + cos(engine.elapsedTime * 7f) * r * 0.2f, r * 0.8f, ballPaint)
            }
            BallRenderStyle.CORE_GLOW -> Unit
        }

        // Bright pure-white central core
        ballPaint.color = ballSkin.coreColor.toInt()
        canvas.drawCircle(bx, by, r * 0.56f, ballPaint)
    }

    private fun drawArenaBorders(
        canvas: Canvas,
        rect: RectF,
        engine: NeonPhysicsEngine,
        theme: ArenaTheme
    ) {
        val borderColor = lerpColor(theme.borderColor.toInt(), engine.currentColor(), 0.45f)

        // Outer neon border bloom
        borderGlowPaint.maskFilter = if (currentQuality.enableBlur) softBlur else null
        borderGlowPaint.color = adjustAlpha(borderColor, 0.55f)
        borderGlowPaint.strokeWidth = 8f
        canvas.drawRect(rect, borderGlowPaint)

        // Bright thin side borders (left & right glow stronger as requested!)
        borderGlowPaint.maskFilter = null
        borderGlowPaint.color = adjustAlpha(borderColor, 0.92f)
        borderGlowPaint.strokeWidth = 3.2f
        canvas.drawLine(rect.left, rect.top, rect.left, rect.bottom, borderGlowPaint)
        canvas.drawLine(rect.right, rect.top, rect.right, rect.bottom, borderGlowPaint)

        // Subtle crisp white inner edge on left & right walls
        borderCorePaint.color = adjustAlpha(Color.WHITE, 0.85f)
        borderCorePaint.strokeWidth = 1.4f
        canvas.drawLine(rect.left, rect.top, rect.left, rect.bottom, borderCorePaint)
        canvas.drawLine(rect.right, rect.top, rect.right, rect.bottom, borderCorePaint)

        // Top & bottom subtle laser bounds
        borderCorePaint.color = adjustAlpha(borderColor, 0.72f)
        borderCorePaint.strokeWidth = 2.0f
        canvas.drawLine(rect.left, rect.top, rect.right, rect.top, borderCorePaint)
        canvas.drawLine(rect.left, rect.bottom, rect.right, rect.bottom, borderCorePaint)

        // Localized wall impact flares
        for (f in engine.wallFlares) {
            if (!f.active) continue
            val alpha = (1f - f.life / f.maxLife).coerceIn(0f, 1f)
            val fx = rect.left + f.x * rect.width()
            val fy = rect.top + f.y * rect.height()
            particlePaint.color = adjustAlpha(f.colorArgb, alpha * 0.85f)
            canvas.drawCircle(fx, fy, 16f * (1f - alpha * 0.3f), particlePaint)
            particlePaint.color = adjustAlpha(Color.WHITE, alpha * 0.9f)
            canvas.drawCircle(fx, fy, 6f, particlePaint)
        }
    }

    private fun blendSkinColor(skin: BallSkin, arenaColor: Int): Int {
        return lerpColor(skin.primaryColor.toInt(), arenaColor, 0.35f)
    }

    private fun lerpColor(c0: Int, c1: Int, t: Float): Int {
        val f = t.coerceIn(0f, 1f)
        val a = ((c0 ushr 24) and 0xFF) + (((c1 ushr 24) and 0xFF) - ((c0 ushr 24) and 0xFF)) * f
        val r = ((c0 ushr 16) and 0xFF) + (((c1 ushr 16) and 0xFF) - ((c0 ushr 16) and 0xFF)) * f
        val g = ((c0 ushr 8) and 0xFF) + (((c1 ushr 8) and 0xFF) - ((c0 ushr 8) and 0xFF)) * f
        val b = (c0 and 0xFF) + ((c1 and 0xFF) - (c0 and 0xFF)) * f
        return (a.toInt() shl 24) or (r.toInt() shl 16) or (g.toInt() shl 8) or b.toInt()
    }

    private fun adjustAlpha(color: Int, factor: Float): Int {
        val a = (((color ushr 24) and 0xFF) * factor.coerceIn(0f, 1f)).toInt().coerceIn(0, 255)
        return (color and 0x00FFFFFF) or (a shl 24)
    }
}
