package com.example.engine

import com.example.model.GameMode
import com.example.model.LevelConfig
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

enum class RunPhase {
    MENU_DEMO,
    READY,
    PLAYING,
    PAUSED,
    LEVEL_COMPLETE,
    GAME_OVER
}

data class WavePulse(
    var active: Boolean = false,
    var x: Float = 0.5f,
    var y: Float = 0.5f,
    var strength: Float = 0f,
    var radius: Float = 0f,
    var maxRadius: Float = 0.7f,
    var age: Float = 0f,
    var duration: Float = 0.85f,
    var colorArgb: Int = 0xFF00F0FF.toInt()
)

data class SparkParticle(
    var active: Boolean = false,
    var x: Float = 0f,
    var y: Float = 0f,
    var vx: Float = 0f,
    var vy: Float = 0f,
    var life: Float = 0f,
    var maxLife: Float = 0.5f,
    var size: Float = 3f,
    var colorArgb: Int = 0xFFFFFFFF.toInt()
)

data class WallFlare(
    var active: Boolean = false,
    var x: Float = 0f,
    var y: Float = 0f,
    var life: Float = 0f,
    var maxLife: Float = 0.4f,
    var colorArgb: Int = 0xFF00F0FF.toInt()
)

data class TrailSample(
    var x: Float = 0.5f,
    var y: Float = 0.5f,
    var hueOffset: Float = 0f,
    var active: Boolean = false
)

data class HarmonicBand(
    var y: Float = 0.45f,
    var xCenter: Float = 0.5f,
    var halfWidth: Float = 0.22f,
    var phase: Float = 0f,
    var speed: Float = 0.25f,
    var hitCooldown: Float = 0f,
    var bendImpulse: Float = 0f
)

data class VoidHazard(
    var x: Float = 0.5f,
    var y: Float = 0.35f,
    var baseX: Float = 0.5f,
    var radius: Float = 0.032f,
    var phase: Float = 0f,
    var orbitAmp: Float = 0.18f,
    var orbitSpeed: Float = 1.2f,
    var hitCooldown: Float = 0f
)

data class HudSnapshot(
    val phase: RunPhase = RunPhase.MENU_DEMO,
    val mode: GameMode = GameMode.CLASSIC,
    val scoreMilestone: Int = 1,
    val milestoneProgress: Float = 0f,
    val bounces: Int = 0,
    val combo: Int = 0,
    val bestScore: Int = 0,
    val levelNumber: Int = 1,
    val targetMilestone: Int = 16,
    val hasShield: Boolean = true,
    val autoMode: Boolean = false,
    val earnedShards: Int = 0,
    val isNewRecord: Boolean = false,
    val starsEarned: Int = 0,
    val milestoneEventId: Int = 0
)

interface EngineAudioCallbacks {
    fun onWallBounce(intensity: Float)
    fun onWaveBounce(combo: Int)
    fun onMilestoneUp(tierIndex: Int, isNewRecord: Boolean)
    fun onEnergyBurst()
    fun onLevelComplete()
    fun onGameOver()
}

class NeonPhysicsEngine {

    companion object {
        const val TRAIL_CAPACITY = 64
        const val PULSE_POOL_SIZE = 18
        const val PARTICLE_POOL_SIZE = 160
        const val FLARE_POOL_SIZE = 12
    }

    var phase: RunPhase = RunPhase.MENU_DEMO
        private set
    var mode: GameMode = GameMode.CLASSIC
        private set
    var autoMode: Boolean = false

    // Ball state in normalized [0..1] arena space
    var ballX: Float = 0.5f
        private set
    var ballY: Float = 0.34f
        private set
    var ballVx: Float = 0.42f
        private set
    var ballVy: Float = 0.58f
        private set
    val ballRadius: Float = 0.023f

    // Player catcher wave at bottom
    var catcherX: Float = 0.5f
        private set
    val catcherY: Float = 0.875f
    var catcherHalfWidth: Float = 0.185f
        private set
    var catcherBend: Float = 0f
        private set
    var catcherBendX: Float = 0.5f
        private set

    // Pointer / hold tension well
    var pointerActive: Boolean = false
        private set
    var pointerX: Float = 0.5f
        private set
    var pointerY: Float = 0.7f
        private set
    private var targetCatcherX: Float = 0.5f

    // Camera subtle motion + shake
    var cameraOffsetX: Float = 0f
        private set
    var cameraOffsetY: Float = 0f
        private set
    var shakeIntensity: Float = 0f
        private set
    var flashAlpha: Float = 0f
        private set

    // Chromatic progression
    var elapsedTime: Float = 0f
        private set
    var colorHueShift: Float = 0f
        private set
    var tierIndex: Int = 0
        private set

    // Scoring
    var currentMilestone: Int = 1
        private set
    var bouncesInRun: Int = 0
        private set
    var comboCount: Int = 0
        private set
    var earnedShardsInRun: Int = 0
        private set
    var hasShield: Boolean = true
        private set
    var isNewRecord: Boolean = false
        private set
    private var bestBeforeRun: Int = 0
    private var tierHits: Int = 0
    private var tierTargetHits: Int = 2
    private var milestoneEventId: Int = 0
    private var levelConfig: LevelConfig? = null

    // Speed control
    private var baseSpeed: Float = 0.72f
    private var currentSpeed: Float = 0.72f
    private var maxSpeed: Float = 1.65f

    // Pools (zero per-frame allocations)
    val trailBuffer = Array(TRAIL_CAPACITY) { TrailSample() }
    var trailHead: Int = 0
        private set
    private var trailSampleTimer: Float = 0f

    val pulses = Array(PULSE_POOL_SIZE) { WavePulse() }
    val particles = Array(PARTICLE_POOL_SIZE) { SparkParticle() }
    val wallFlares = Array(FLARE_POOL_SIZE) { WallFlare() }

    val harmonicBands = mutableListOf<HarmonicBand>()
    val hazards = mutableListOf<VoidHazard>()

    var audioCallbacks: EngineAudioCallbacks? = null
    var onRunFinished: ((HudSnapshot) -> Unit)? = null
    private var runFinishedNotified = false

    private var currentPalette: IntArray = intArrayOf(
        0xFF0088FF.toInt(),
        0xFF00F0FF.toInt(),
        0xFF9D4EDD.toInt(),
        0xFFFF2E93.toInt(),
        0xFF00FF87.toInt(),
        0xFFFFE600.toInt()
    )

    init {
        startMenuDemo()
    }

    fun setPalette(colors: List<Long>) {
        if (colors.isNotEmpty()) {
            currentPalette = colors.map { it.toInt() }.toIntArray()
        }
    }

    fun startMenuDemo() {
        phase = RunPhase.MENU_DEMO
        mode = GameMode.CLASSIC
        autoMode = true
        resetWorldState(speedMult = 0.92f, harmonicCount = 2, hazardCount = 0)
        ballVx = 0.44f
        ballVy = 0.62f
    }

    fun startNewGame(
        gameMode: GameMode,
        bestScore: Int,
        level: LevelConfig? = null,
        keepAuto: Boolean = false
    ) {
        mode = gameMode
        levelConfig = level
        bestBeforeRun = bestScore
        autoMode = keepAuto
        phase = RunPhase.READY
        runFinishedNotified = false

        val speedMult = level?.speedMultiplier ?: 1.0f
        val harmonicCount = level?.harmonicNodes ?: 2
        val hazardCount = level?.hazardCount ?: 0
        resetWorldState(speedMult = speedMult, harmonicCount = harmonicCount, hazardCount = hazardCount)
    }

    private fun resetWorldState(speedMult: Float, harmonicCount: Int, hazardCount: Int) {
        ballX = 0.5f
        ballY = 0.30f
        baseSpeed = 0.74f * speedMult
        currentSpeed = baseSpeed
        maxSpeed = 1.72f * speedMult.coerceAtMost(1.35f)
        val angle = (Random.nextFloat() - 0.5f) * 0.7f
        ballVx = sin(angle) * currentSpeed
        ballVy = cos(angle) * currentSpeed

        catcherX = 0.5f
        targetCatcherX = 0.5f
        catcherHalfWidth = if (mode == GameMode.LEVELS && (levelConfig?.number ?: 1) > 30) 0.16f else 0.185f
        catcherBend = 0f
        pointerActive = false

        currentMilestone = 1
        tierIndex = 0
        tierHits = 0
        tierTargetHits = 2
        bouncesInRun = 0
        comboCount = 0
        earnedShardsInRun = 0
        hasShield = true
        isNewRecord = false
        flashAlpha = 0f
        shakeIntensity = 0f
        cameraOffsetX = 0f
        cameraOffsetY = 0f
        colorHueShift = 0f

        for (i in trailBuffer.indices) trailBuffer[i].active = false
        trailHead = 0
        for (p in pulses) p.active = false
        for (pt in particles) pt.active = false
        for (f in wallFlares) f.active = false

        harmonicBands.clear()
        for (i in 0 until harmonicCount) {
            val yPos = 0.34f + i * 0.19f
            harmonicBands.add(
                HarmonicBand(
                    y = yPos.coerceIn(0.24f, 0.70f),
                    xCenter = 0.28f + (i * 0.35f) % 0.44f,
                    halfWidth = 0.17f,
                    phase = i * 1.9f,
                    speed = (0.20f + i * 0.08f) * if (i % 2 == 0) 1f else -1f
                )
            )
        }

        hazards.clear()
        for (i in 0 until hazardCount) {
            hazards.add(
                VoidHazard(
                    x = 0.5f,
                    y = 0.25f + i * 0.14f,
                    baseX = 0.5f,
                    radius = 0.030f,
                    phase = i * 2.1f,
                    orbitAmp = 0.26f,
                    orbitSpeed = 1.05f + i * 0.25f
                )
            )
        }
    }

    fun launchIfReady() {
        if (phase == RunPhase.READY) {
            phase = RunPhase.PLAYING
            spawnPulse(ballX, ballY, 0.9f, 0.65f, currentColor())
            audioCallbacks?.onWaveBounce(1)
        }
    }

    fun pause() {
        if (phase == RunPhase.PLAYING) {
            phase = RunPhase.PAUSED
        }
    }

    fun resume() {
        if (phase == RunPhase.PAUSED) {
            phase = RunPhase.PLAYING
        }
    }

    fun onTap(normX: Float, normY: Float) {
        if (phase == RunPhase.READY) {
            launchIfReady()
            return
        }
        if (phase != RunPhase.PLAYING) return

        val cx = normX.coerceIn(0.05f, 0.95f)
        val cy = normY.coerceIn(0.08f, 0.95f)
        spawnPulse(cx, cy, 0.75f, 0.5f, currentColor())

        if (!autoMode) {
            targetCatcherX = cx.coerceIn(catcherHalfWidth, 1f - catcherHalfWidth)
            // Gentle radial impulse if tap is near ball
            val dx = ballX - cx
            val dy = ballY - cy
            val dist = hypot(dx, dy)
            if (dist in 0.01f..0.28f) {
                val push = (1f - dist / 0.28f) * 0.22f * currentSpeed
                ballVx += (dx / dist) * push
                ballVy += (dy / dist) * push
                normalizeBallSpeed()
            }
        }
    }

    fun onDrag(normX: Float, normY: Float, active: Boolean) {
        pointerActive = active
        if (!active) return
        pointerX = normX.coerceIn(0.02f, 0.98f)
        pointerY = normY.coerceIn(0.08f, 0.96f)
        if (phase == RunPhase.READY) {
            launchIfReady()
        }
        if (phase == RunPhase.PLAYING && !autoMode) {
            targetCatcherX = pointerX.coerceIn(catcherHalfWidth, 1f - catcherHalfWidth)
        }
    }

    fun onSwipe(dxNorm: Float, dyNorm: Float, startX: Float, startY: Float) {
        if (phase == RunPhase.READY) {
            launchIfReady()
        }
        if (phase != RunPhase.PLAYING || autoMode) return

        val mag = hypot(dxNorm, dyNorm)
        if (mag < 0.03f) return

        val nx = dxNorm / mag
        val ny = dyNorm / mag

        // Steer velocity smoothly in swipe direction
        val blend = 0.55f
        val newVx = ballVx * (1f - blend) + nx * currentSpeed * blend * 1.15f
        val newVy = ballVy * (1f - blend) + ny * currentSpeed * blend * 1.15f
        ballVx = newVx
        ballVy = newVy
        normalizeBallSpeed()

        spawnPulse(startX.coerceIn(0.05f, 0.95f), startY.coerceIn(0.1f, 0.95f), 0.95f, 0.55f, currentColor())
        spawnSparks(ballX, ballY, 8, currentColor())
        audioCallbacks?.onWallBounce(0.8f)
    }

    fun step(rawDt: Float, particleFactor: Float = 1f) {
        val dt = rawDt.coerceIn(0.001f, 0.033f)
        elapsedTime += dt

        // Decay visual transients
        flashAlpha = max(0f, flashAlpha - dt * 2.4f)
        shakeIntensity = max(0f, shakeIntensity - dt * 3.8f)
        catcherBend *= (1f - min(1f, dt * 11f))

        // Update pulses & particles & flares even during pause/ready transitions (except paused)
        if (phase == RunPhase.PAUSED) return

        updateEffects(dt)

        if (phase == RunPhase.READY) {
            // Subtle hovering idle animation
            ballY = 0.30f + sin(elapsedTime * 3.2f) * 0.015f
            recordTrailSample(dt)
            return
        }

        if (phase == RunPhase.GAME_OVER || phase == RunPhase.LEVEL_COMPLETE) {
            return
        }

        // Update harmonic bands & hazards
        for (band in harmonicBands) {
            band.phase += dt * 2.2f
            band.xCenter += band.speed * dt
            if (band.xCenter < band.halfWidth + 0.04f) {
                band.xCenter = band.halfWidth + 0.04f
                band.speed = abs(band.speed)
            } else if (band.xCenter > 1f - band.halfWidth - 0.04f) {
                band.xCenter = 1f - band.halfWidth - 0.04f
                band.speed = -abs(band.speed)
            }
            if (band.hitCooldown > 0f) band.hitCooldown = max(0f, band.hitCooldown - dt)
            band.bendImpulse *= (1f - min(1f, dt * 10f))
        }

        for (hazard in hazards) {
            hazard.phase += dt * hazard.orbitSpeed
            hazard.x = (hazard.baseX + sin(hazard.phase) * hazard.orbitAmp).coerceIn(0.10f, 0.90f)
            if (hazard.hitCooldown > 0f) hazard.hitCooldown = max(0f, hazard.hitCooldown - dt)
        }

        // Auto Mode or Menu Demo steering
        if (autoMode || phase == RunPhase.MENU_DEMO) {
            updateAutoPilot()
        }

        // Smooth catcher movement
        val followSpeed = if (autoMode || phase == RunPhase.MENU_DEMO) 13.5f else 18.0f
        catcherX += (targetCatcherX - catcherX) * min(1f, dt * followSpeed)
        catcherX = catcherX.coerceIn(catcherHalfWidth, 1f - catcherHalfWidth)

        // Hold gravity pull / subtle energy attraction
        if (pointerActive && phase == RunPhase.PLAYING && !autoMode) {
            val dx = pointerX - ballX
            val dy = pointerY - ballY
            val dist = hypot(dx, dy)
            if (dist in 0.04f..0.38f) {
                // Gently bend ball toward held wave well if falling
                val pull = 0.45f * dt
                ballVx += (dx / dist) * pull
                normalizeBallSpeed()
            }
        }

        // Sub-step physics for tunnel-proof collisions at high speeds
        val subSteps = 2
        val subDt = dt / subSteps
        for (s in 0 until subSteps) {
            stepBallSub(subDt, particleFactor)
            if (phase == RunPhase.GAME_OVER || phase == RunPhase.LEVEL_COMPLETE) break
        }

        // Smooth camera tracking keeping arena centered
        val targetCamX = (ballX - 0.5f) * 0.018f
        val targetCamY = (ballY - 0.5f) * 0.014f
        cameraOffsetX += (targetCamX - cameraOffsetX) * min(1f, dt * 5f)
        cameraOffsetY += (targetCamY - cameraOffsetY) * min(1f, dt * 5f)

        // Subtle continuous chromatic shift
        colorHueShift = (colorHueShift + dt * 0.03f) % 1f
        recordTrailSample(dt)
    }

    private fun updateAutoPilot() {
        // Predict X when ball approaches bottom wave, steering slightly off-center to aim at harmonic bands
        var desiredX = ballX
        if (ballVy > 0.05f) {
            val timeToCatcher = ((catcherY - ballY) / ballVy).coerceIn(0f, 1.5f)
            var predX = ballX + ballVx * timeToCatcher
            // Reflect predicted wall bounces
            while (predX < ballRadius || predX > 1f - ballRadius) {
                predX = if (predX < ballRadius) {
                    2f * ballRadius - predX
                } else {
                    2f * (1f - ballRadius) - predX
                }
            }
            val targetBand = harmonicBands.firstOrNull()
            val aimOffset = if (targetBand != null) {
                ((predX - targetBand.xCenter) * 0.25f).coerceIn(-0.08f, 0.08f)
            } else {
                sin(elapsedTime * 1.7f) * 0.06f
            }
            desiredX = predX + aimOffset
        }
        targetCatcherX = desiredX.coerceIn(catcherHalfWidth, 1f - catcherHalfWidth)
    }

    private fun stepBallSub(dt: Float, particleFactor: Float) {
        val prevY = ballY
        ballX += ballVx * dt
        ballY += ballVy * dt

        // Left / Right walls
        if (ballX <= ballRadius) {
            ballX = ballRadius
            ballVx = abs(ballVx)
            onWallHit(0f, ballY, particleFactor)
        } else if (ballX >= 1f - ballRadius) {
            ballX = 1f - ballRadius
            ballVx = -abs(ballVx)
            onWallHit(1f, ballY, particleFactor)
        }

        // Top border
        if (ballY <= ballRadius) {
            ballY = ballRadius
            ballVy = abs(ballVy)
            onWallHit(ballX, 0f, particleFactor)
        }

        // Mid-arena Harmonic Wave Bands interaction
        for (band in harmonicBands) {
            if (band.hitCooldown <= 0f) {
                val dx = abs(ballX - band.xCenter)
                val dy = abs(ballY - band.y)
                if (dx <= band.halfWidth + ballRadius && dy <= ballRadius + 0.016f) {
                    band.hitCooldown = 0.28f
                    band.bendImpulse = if (ballVy > 0) 1.0f else -1.0f
                    // Deflect / slingshot cleanly based on hit position along the band
                    val rel = ((ballX - band.xCenter) / band.halfWidth).coerceIn(-1f, 1f)
                    if (ballVy > 0f && phase != RunPhase.MENU_DEMO) {
                        // Bounce off or slice through with energetic ripple!
                        ballVy = -abs(ballVy) * 0.96f
                        ballVx += rel * currentSpeed * 0.38f
                    } else {
                        ballVx += rel * currentSpeed * 0.24f
                    }
                    accelerateSlightly()
                    normalizeBallSpeed()

                    spawnPulse(ballX, band.y, 1.15f, 0.75f, currentColor())
                    spawnSparks(ballX, band.y, (14 * particleFactor).toInt().coerceAtLeast(4), currentColor())
                    shakeIntensity = max(shakeIntensity, 0.45f)

                    if (phase == RunPhase.PLAYING) {
                        registerSuccessfulBounce(hitBonus = 2, shardBonus = 3)
                    } else if (phase == RunPhase.MENU_DEMO) {
                        colorHueShift = (colorHueShift + 0.08f) % 1f
                    }
                }
            }
        }

        // Void hazards check (only in PLAYING mode)
        if (phase == RunPhase.PLAYING) {
            for (hazard in hazards) {
                if (hazard.hitCooldown <= 0f) {
                    val dist = hypot(ballX - hazard.x, ballY - hazard.y)
                    if (dist <= ballRadius + hazard.radius * 0.85f) {
                        hazard.hitCooldown = 0.6f
                        if (hasShield) {
                            hasShield = false
                            comboCount = 0
                            spawnPulse(hazard.x, hazard.y, 1.3f, 0.8f, 0xFFFF2E93.toInt())
                            spawnSparks(hazard.x, hazard.y, 18, 0xFFFF2E93.toInt())
                            shakeIntensity = 0.9f
                            audioCallbacks?.onEnergyBurst()
                            // Bounce away safely
                            val nx = (ballX - hazard.x) / max(0.001f, dist)
                            val ny = (ballY - hazard.y) / max(0.001f, dist)
                            ballVx = nx * currentSpeed
                            ballVy = ny * currentSpeed
                        } else {
                            triggerGameOver()
                            return
                        }
                    }
                }
            }
        }

        // Catcher Wave collision near bottom
        val waveZoneTop = catcherY - ballRadius - 0.012f
        if (ballVy > 0f && prevY <= waveZoneTop + 0.03f && ballY >= waveZoneTop) {
            val rel = (ballX - catcherX) / catcherHalfWidth
            if (abs(rel) <= 1.14f || phase == RunPhase.MENU_DEMO) {
                val clampedRel = rel.coerceIn(-1f, 1f)
                ballY = waveZoneTop
                // Bounce angle depends directly on impact point along the U/V curve!
                val maxBounceAngle = (56.0 * PI / 180.0).toFloat()
                val bounceAngle = clampedRel * maxBounceAngle
                accelerateSlightly()
                ballVx = sin(bounceAngle) * currentSpeed
                ballVy = -cos(bounceAngle) * currentSpeed

                catcherBend = 1.0f
                catcherBendX = ballX

                val pulseStrength = if (pointerActive) 1.35f else 1.05f
                spawnPulse(ballX, catcherY, pulseStrength, 0.85f, currentColor())
                spawnSparks(ballX, catcherY, (16 * particleFactor).toInt().coerceAtLeast(5), currentColor())
                shakeIntensity = max(shakeIntensity, 0.35f)

                if (phase == RunPhase.PLAYING) {
                    val holdBonus = if (pointerActive) 1 else 0
                    registerSuccessfulBounce(hitBonus = 1 + holdBonus, shardBonus = 2)
                } else if (phase == RunPhase.MENU_DEMO) {
                    audioCallbacks?.let { /* silent in menu demo */ }
                    flashAlpha = max(flashAlpha, 0.14f)
                }
            }
        }

        // Bottom breach check
        if (ballY >= 1f - ballRadius) {
            if (phase == RunPhase.MENU_DEMO || autoMode) {
                ballY = 1f - ballRadius
                ballVy = -abs(ballVy)
                spawnPulse(ballX, 1f, 0.9f, 0.6f, currentColor())
            } else if (phase == RunPhase.PLAYING) {
                if (hasShield) {
                    // Emergency bottom wave shield bounce once per tier!
                    hasShield = false
                    comboCount = 0
                    ballY = 1f - ballRadius
                    ballVy = -abs(ballVy)
                    spawnPulse(ballX, 0.98f, 1.35f, 0.85f, 0xFFFF2E93.toInt())
                    spawnSparks(ballX, 0.98f, 20, 0xFFFF2E93.toInt())
                    shakeIntensity = 0.85f
                    audioCallbacks?.onEnergyBurst()
                } else {
                    triggerGameOver()
                }
            }
        }
    }

    private fun onWallHit(x: Float, y: Float, particleFactor: Float) {
        val c = currentColor()
        spawnFlare(x, y, c)
        spawnPulse(x, y, 0.72f, 0.55f, c)
        spawnSparks(x, y, (8 * particleFactor).toInt().coerceAtLeast(3), c)
        if (phase == RunPhase.PLAYING) {
            audioCallbacks?.onWallBounce((currentSpeed / maxSpeed).coerceIn(0.4f, 1.2f))
        }
    }

    private fun registerSuccessfulBounce(hitBonus: Int, shardBonus: Int) {
        bouncesInRun += 1
        comboCount += 1
        earnedShardsInRun += shardBonus + (comboCount / 6)
        tierHits += hitBonus

        audioCallbacks?.onWaveBounce(comboCount)

        if (tierHits >= tierTargetHits) {
            tierHits = 0
            tierIndex += 1
            currentMilestone *= 2
            tierTargetHits = when {
                tierIndex <= 2 -> 2
                tierIndex <= 5 -> 3
                tierIndex <= 8 -> 4
                else -> 5
            }
            // Recharge shield on milestone up!
            hasShield = true
            milestoneEventId += 1
            colorHueShift = (colorHueShift + 0.16f) % 1f
            flashAlpha = 0.55f
            shakeIntensity = 0.95f

            val burstColor = currentColor()
            spawnPulse(ballX, ballY, 1.65f, 1.05f, burstColor)
            spawnSparks(ballX, ballY, 26, burstColor)

            val beatRecordNow = !isNewRecord && bestBeforeRun > 0 && currentMilestone > bestBeforeRun && mode != GameMode.LEVELS
            if (beatRecordNow || (bestBeforeRun == 0 && currentMilestone >= 4 && mode != GameMode.LEVELS)) {
                isNewRecord = true
                flashAlpha = 0.85f
                audioCallbacks?.onMilestoneUp(tierIndex, isNewRecord = true)
            } else {
                audioCallbacks?.onMilestoneUp(tierIndex, isNewRecord = false)
            }

            // Check level completion
            val lvl = levelConfig
            if (mode == GameMode.LEVELS && lvl != null) {
                if (currentMilestone >= lvl.targetMilestone && bouncesInRun >= lvl.requiredBounces / 2) {
                    triggerLevelComplete(lvl)
                    return
                }
            }
        }

        // Also check level completion if bounces & milestone already satisfied
        val lvl = levelConfig
        if (mode == GameMode.LEVELS && lvl != null && currentMilestone >= lvl.targetMilestone && bouncesInRun >= lvl.requiredBounces) {
            triggerLevelComplete(lvl)
        }
    }

    private fun triggerLevelComplete(lvl: LevelConfig) {
        phase = RunPhase.LEVEL_COMPLETE
        earnedShardsInRun += lvl.rewardShards
        flashAlpha = 0.8f
        spawnPulse(ballX, ballY, 1.8f, 1.15f, currentColor())
        spawnSparks(ballX, ballY, 36, currentColor())
        audioCallbacks?.onLevelComplete()
        notifyRunFinished()
    }

    private fun triggerGameOver() {
        phase = RunPhase.GAME_OVER
        shakeIntensity = 1.0f
        flashAlpha = 0.5f
        spawnSparks(ballX, ballY, 30, 0xFFFF2E93.toInt())
        audioCallbacks?.onGameOver()
        notifyRunFinished()
    }

    private fun notifyRunFinished() {
        if (!runFinishedNotified) {
            runFinishedNotified = true
            onRunFinished?.invoke(snapshot())
        }
    }

    private fun accelerateSlightly() {
        val accelStep = when (mode) {
            GameMode.CLASSIC -> 0.018f
            GameMode.ENDLESS -> 0.022f
            GameMode.LEVELS -> 0.015f
        }
        currentSpeed = (currentSpeed + accelStep).coerceAtMost(maxSpeed)
    }

    private fun normalizeBallSpeed() {
        val mag = hypot(ballVx, ballVy)
        if (mag > 0.0001f) {
            // Prevent nearly horizontal infinite loops by enforcing min vertical component
            var vx = (ballVx / mag) * currentSpeed
            var vy = (ballVy / mag) * currentSpeed
            val minVy = currentSpeed * 0.28f
            if (abs(vy) < minVy) {
                vy = if (vy >= 0f) minVy else -minVy
                val rem = sqrt(max(0f, currentSpeed * currentSpeed - vy * vy))
                vx = if (vx >= 0f) rem else -rem
            }
            ballVx = vx
            ballVy = vy
        }
    }

    private fun recordTrailSample(dt: Float) {
        trailSampleTimer += dt
        if (trailSampleTimer >= 0.010f) {
            trailSampleTimer = 0f
            val sample = trailBuffer[trailHead]
            sample.x = ballX
            sample.y = ballY
            sample.hueOffset = colorHueShift
            sample.active = true
            trailHead = (trailHead + 1) % TRAIL_CAPACITY
        }
    }

    private fun updateEffects(dt: Float) {
        for (p in pulses) {
            if (!p.active) continue
            p.age += dt
            if (p.age >= p.duration) {
                p.active = false
            } else {
                val progress = p.age / p.duration
                p.radius = progress * p.maxRadius
            }
        }

        for (pt in particles) {
            if (!pt.active) continue
            pt.life += dt
            if (pt.life >= pt.maxLife) {
                pt.active = false
            } else {
                pt.x += pt.vx * dt
                pt.y += pt.vy * dt
                pt.vx *= (1f - dt * 2.5f)
                pt.vy *= (1f - dt * 2.5f)
            }
        }

        for (f in wallFlares) {
            if (!f.active) continue
            f.life += dt
            if (f.life >= f.maxLife) {
                f.active = false
            }
        }
    }

    fun spawnPulse(x: Float, y: Float, strength: Float, maxRadius: Float, colorArgb: Int) {
        val slot = pulses.firstOrNull { !it.active } ?: pulses.maxByOrNull { it.age } ?: return
        slot.active = true
        slot.x = x
        slot.y = y
        slot.strength = strength
        slot.radius = 0.01f
        slot.maxRadius = maxRadius
        slot.age = 0f
        slot.duration = 0.78f
        slot.colorArgb = colorArgb
    }

    private fun spawnSparks(x: Float, y: Float, count: Int, colorArgb: Int) {
        var spawned = 0
        for (pt in particles) {
            if (!pt.active) {
                val angle = Random.nextFloat() * 2f * PI.toFloat()
                val speed = 0.16f + Random.nextFloat() * 0.48f
                pt.active = true
                pt.x = x
                pt.y = y
                pt.vx = cos(angle) * speed
                pt.vy = sin(angle) * speed
                pt.life = 0f
                pt.maxLife = 0.28f + Random.nextFloat() * 0.34f
                pt.size = 2.5f + Random.nextFloat() * 3.5f
                pt.colorArgb = colorArgb
                spawned++
                if (spawned >= count) break
            }
        }
    }

    private fun spawnFlare(x: Float, y: Float, colorArgb: Int) {
        val slot = wallFlares.firstOrNull { !it.active } ?: wallFlares.maxByOrNull { it.life } ?: return
        slot.active = true
        slot.x = x
        slot.y = y
        slot.life = 0f
        slot.maxLife = 0.42f
        slot.colorArgb = colorArgb
    }

    fun currentColor(): Int {
        if (currentPalette.isEmpty()) return 0xFF00F0FF.toInt()
        val idx = (tierIndex + (colorHueShift * currentPalette.size).toInt()) % currentPalette.size
        return currentPalette[idx.coerceIn(0, currentPalette.lastIndex)]
    }

    fun snapshot(): HudSnapshot {
        val stars = if (phase == RunPhase.LEVEL_COMPLETE) {
            when {
                hasShield && comboCount >= 8 -> 3
                hasShield || comboCount >= 4 -> 2
                else -> 1
            }
        } else 0

        return HudSnapshot(
            phase = phase,
            mode = mode,
            scoreMilestone = currentMilestone,
            milestoneProgress = (tierHits.toFloat() / tierTargetHits.toFloat()).coerceIn(0f, 1f),
            bounces = bouncesInRun,
            combo = comboCount,
            bestScore = when (mode) {
                GameMode.CLASSIC -> maxOf(bestBeforeRun, currentMilestone)
                GameMode.ENDLESS -> maxOf(bestBeforeRun, currentMilestone)
                GameMode.LEVELS -> levelConfig?.targetMilestone ?: 16
            },
            levelNumber = levelConfig?.number ?: 1,
            targetMilestone = levelConfig?.targetMilestone ?: 16,
            hasShield = hasShield,
            autoMode = autoMode,
            earnedShards = earnedShardsInRun,
            isNewRecord = isNewRecord,
            starsEarned = stars,
            milestoneEventId = milestoneEventId
        )
    }
}
