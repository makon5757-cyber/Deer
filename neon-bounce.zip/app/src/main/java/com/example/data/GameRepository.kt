package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.model.AppLanguage
import com.example.model.AppState
import com.example.model.GameCatalog
import com.example.model.GameMode
import com.example.model.GameProgress
import com.example.model.GameSettings
import com.example.model.GraphicsQuality
import com.example.model.TargetFps
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GameRepository(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(loadState())
    val state: StateFlow<AppState> = _state.asStateFlow()

    private fun currentEpochDay(): Long =
        TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis())

    private fun computeDailyRewardAmount(streak: Int): Int {
        val cycle = (streak % 7) + 1
        return when (cycle) {
            1 -> 75
            2 -> 100
            3 -> 140
            4 -> 180
            5 -> 240
            6 -> 320
            else -> 500
        }
    }

    private fun loadState(): AppState {
        val music = prefs.getBoolean(KEY_MUSIC, true)
        val sound = prefs.getBoolean(KEY_SOUND, true)
        val vibration = prefs.getBoolean(KEY_VIBRATION, true)
        val quality = runCatching {
            GraphicsQuality.valueOf(prefs.getString(KEY_QUALITY, GraphicsQuality.HIGH.name) ?: GraphicsQuality.HIGH.name)
        }.getOrDefault(GraphicsQuality.HIGH)
        val fps = runCatching {
            TargetFps.valueOf(prefs.getString(KEY_FPS, TargetFps.FPS_60.name) ?: TargetFps.FPS_60.name)
        }.getOrDefault(TargetFps.FPS_60)
        val language = runCatching {
            AppLanguage.valueOf(prefs.getString(KEY_LANGUAGE, AppLanguage.RU.name) ?: AppLanguage.RU.name)
        }.getOrDefault(AppLanguage.RU)
        val selectedTheme = prefs.getString(KEY_SELECTED_THEME, "cyber_spectrum") ?: "cyber_spectrum"

        val unlockedBalls = prefs.getStringSet(KEY_UNLOCKED_BALLS, setOf("classic_cyan"))?.toSet()
            ?: setOf("classic_cyan")
        val unlockedTrails = prefs.getStringSet(KEY_UNLOCKED_TRAILS, setOf("smooth_ribbon"))?.toSet()
            ?: setOf("smooth_ribbon")
        val unlockedThemes = prefs.getStringSet(KEY_UNLOCKED_THEMES, setOf("cyber_spectrum"))?.toSet()
            ?: setOf("cyber_spectrum")

        val levelStarsJson = prefs.getString(KEY_LEVEL_STARS, "{}") ?: "{}"
        val levelStars = parseIntMap(levelStarsJson)

        val historyStr = prefs.getString(KEY_MILESTONE_HISTORY, "") ?: ""
        val milestoneHistory = if (historyStr.isBlank()) {
            emptyList()
        } else {
            historyStr.split(",").mapNotNull { it.toIntOrNull() }
        }

        val streak = prefs.getInt(KEY_DAILY_STREAK, 0)
        val lastClaimDay = prefs.getLong(KEY_LAST_DAILY_DAY, -1L)
        val today = currentEpochDay()
        val canClaim = lastClaimDay < today
        val effectiveStreak = if (lastClaimDay >= 0 && today - lastClaimDay > 1L) 0 else streak

        val progress = GameProgress(
            shards = prefs.getInt(KEY_SHARDS, 120),
            bestClassicScore = prefs.getInt(KEY_BEST_CLASSIC, 0),
            bestEndlessScore = prefs.getInt(KEY_BEST_ENDLESS, 0),
            highestMilestone = prefs.getInt(KEY_HIGHEST_MILESTONE, 1),
            totalBounces = prefs.getLong(KEY_TOTAL_BOUNCES, 0L),
            totalGamesPlayed = prefs.getInt(KEY_GAMES_PLAYED, 0),
            highestUnlockedLevel = prefs.getInt(KEY_HIGHEST_LEVEL, 1).coerceIn(1, 50),
            levelStars = levelStars,
            unlockedBallIds = unlockedBalls + "classic_cyan",
            unlockedTrailIds = unlockedTrails + "smooth_ribbon",
            unlockedThemeIds = unlockedThemes + "cyber_spectrum",
            equippedBallId = prefs.getString(KEY_EQUIPPED_BALL, "classic_cyan") ?: "classic_cyan",
            equippedTrailId = prefs.getString(KEY_EQUIPPED_TRAIL, "smooth_ribbon") ?: "smooth_ribbon",
            dailyStreak = effectiveStreak,
            lastDailyClaimDay = lastClaimDay,
            milestoneHistory = milestoneHistory
        )

        val settings = GameSettings(
            musicEnabled = music,
            soundEnabled = sound,
            vibrationEnabled = vibration,
            graphicsQuality = quality,
            targetFps = fps,
            language = language,
            selectedThemeId = selectedTheme
        )

        return AppState(
            settings = settings,
            progress = progress,
            canClaimDailyReward = canClaim,
            nextDailyRewardAmount = computeDailyRewardAmount(effectiveStreak)
        )
    }

    fun updateSettings(transform: (GameSettings) -> GameSettings) {
        val current = _state.value
        val updated = transform(current.settings)
        prefs.edit()
            .putBoolean(KEY_MUSIC, updated.musicEnabled)
            .putBoolean(KEY_SOUND, updated.soundEnabled)
            .putBoolean(KEY_VIBRATION, updated.vibrationEnabled)
            .putString(KEY_QUALITY, updated.graphicsQuality.name)
            .putString(KEY_FPS, updated.targetFps.name)
            .putString(KEY_LANGUAGE, updated.language.name)
            .putString(KEY_SELECTED_THEME, updated.selectedThemeId)
            .apply()
        _state.value = current.copy(settings = updated)
    }

    fun claimDailyReward(): Int {
        val current = _state.value
        val today = currentEpochDay()
        if (current.progress.lastDailyClaimDay >= today) return 0

        val wasConsecutive = current.progress.lastDailyClaimDay == today - 1L
        val newStreak = if (wasConsecutive) current.progress.dailyStreak + 1 else 1
        val reward = computeDailyRewardAmount(newStreak - 1)
        val newShards = current.progress.shards + reward

        prefs.edit()
            .putInt(KEY_SHARDS, newShards)
            .putInt(KEY_DAILY_STREAK, newStreak)
            .putLong(KEY_LAST_DAILY_DAY, today)
            .apply()

        _state.value = current.copy(
            progress = current.progress.copy(
                shards = newShards,
                dailyStreak = newStreak,
                lastDailyClaimDay = today
            ),
            canClaimDailyReward = false,
            nextDailyRewardAmount = computeDailyRewardAmount(newStreak)
        )
        return reward
    }

    fun buyOrEquipBall(skinId: String): Boolean {
        val skin = GameCatalog.getBallSkin(skinId)
        val current = _state.value
        val prog = current.progress
        return if (skin.id in prog.unlockedBallIds) {
            prefs.edit().putString(KEY_EQUIPPED_BALL, skin.id).apply()
            _state.value = current.copy(progress = prog.copy(equippedBallId = skin.id))
            true
        } else if (prog.shards >= skin.cost) {
            val newShards = prog.shards - skin.cost
            val newUnlocked = prog.unlockedBallIds + skin.id
            prefs.edit()
                .putInt(KEY_SHARDS, newShards)
                .putStringSet(KEY_UNLOCKED_BALLS, newUnlocked)
                .putString(KEY_EQUIPPED_BALL, skin.id)
                .apply()
            _state.value = current.copy(
                progress = prog.copy(
                    shards = newShards,
                    unlockedBallIds = newUnlocked,
                    equippedBallId = skin.id
                )
            )
            true
        } else {
            false
        }
    }

    fun buyOrEquipTrail(trailId: String): Boolean {
        val trail = GameCatalog.getTrailSkin(trailId)
        val current = _state.value
        val prog = current.progress
        return if (trail.id in prog.unlockedTrailIds) {
            prefs.edit().putString(KEY_EQUIPPED_TRAIL, trail.id).apply()
            _state.value = current.copy(progress = prog.copy(equippedTrailId = trail.id))
            true
        } else if (prog.shards >= trail.cost) {
            val newShards = prog.shards - trail.cost
            val newUnlocked = prog.unlockedTrailIds + trail.id
            prefs.edit()
                .putInt(KEY_SHARDS, newShards)
                .putStringSet(KEY_UNLOCKED_TRAILS, newUnlocked)
                .putString(KEY_EQUIPPED_TRAIL, trail.id)
                .apply()
            _state.value = current.copy(
                progress = prog.copy(
                    shards = newShards,
                    unlockedTrailIds = newUnlocked,
                    equippedTrailId = trail.id
                )
            )
            true
        } else {
            false
        }
    }

    fun buyOrEquipTheme(themeId: String): Boolean {
        val theme = GameCatalog.getArenaTheme(themeId)
        val current = _state.value
        val prog = current.progress
        return if (theme.id in prog.unlockedThemeIds) {
            updateSettings { it.copy(selectedThemeId = theme.id) }
            true
        } else if (prog.shards >= theme.cost) {
            val newShards = prog.shards - theme.cost
            val newUnlocked = prog.unlockedThemeIds + theme.id
            prefs.edit()
                .putInt(KEY_SHARDS, newShards)
                .putStringSet(KEY_UNLOCKED_THEMES, newUnlocked)
                .putString(KEY_SELECTED_THEME, theme.id)
                .apply()
            _state.value = current.copy(
                settings = current.settings.copy(selectedThemeId = theme.id),
                progress = prog.copy(
                    shards = newShards,
                    unlockedThemeIds = newUnlocked
                )
            )
            true
        } else {
            false
        }
    }

    fun recordRunResult(
        mode: GameMode,
        milestoneReached: Int,
        bouncesInRun: Int,
        earnedShards: Int,
        levelNumber: Int = 1,
        levelCleared: Boolean = false,
        starsEarned: Int = 0
    ) {
        val current = _state.value
        val prog = current.progress

        val newClassicBest = if (mode == GameMode.CLASSIC && milestoneReached > prog.bestClassicScore) {
            milestoneReached
        } else {
            prog.bestClassicScore
        }

        val newEndlessBest = if (mode == GameMode.ENDLESS && milestoneReached > prog.bestEndlessScore) {
            milestoneReached
        } else {
            prog.bestEndlessScore
        }

        val newHighestMilestone = maxOf(prog.highestMilestone, milestoneReached)
        val newTotalBounces = prog.totalBounces + bouncesInRun.toLong()
        val newGamesPlayed = prog.totalGamesPlayed + 1
        val newShards = prog.shards + earnedShards

        val updatedStars = prog.levelStars.toMutableMap()
        var newHighestUnlocked = prog.highestUnlockedLevel
        if (mode == GameMode.LEVELS && levelCleared) {
            val prevStars = updatedStars[levelNumber] ?: 0
            if (starsEarned > prevStars) {
                updatedStars[levelNumber] = starsEarned.coerceIn(1, 3)
            }
            if (levelNumber >= newHighestUnlocked && levelNumber < 50) {
                newHighestUnlocked = levelNumber + 1
            }
        }

        val newHistory = (listOf(milestoneReached) + prog.milestoneHistory).take(20)

        prefs.edit()
            .putInt(KEY_SHARDS, newShards)
            .putInt(KEY_BEST_CLASSIC, newClassicBest)
            .putInt(KEY_BEST_ENDLESS, newEndlessBest)
            .putInt(KEY_HIGHEST_MILESTONE, newHighestMilestone)
            .putLong(KEY_TOTAL_BOUNCES, newTotalBounces)
            .putInt(KEY_GAMES_PLAYED, newGamesPlayed)
            .putInt(KEY_HIGHEST_LEVEL, newHighestUnlocked)
            .putString(KEY_LEVEL_STARS, serializeIntMap(updatedStars))
            .putString(KEY_MILESTONE_HISTORY, newHistory.joinToString(","))
            .apply()

        _state.value = current.copy(
            progress = prog.copy(
                shards = newShards,
                bestClassicScore = newClassicBest,
                bestEndlessScore = newEndlessBest,
                highestMilestone = newHighestMilestone,
                totalBounces = newTotalBounces,
                totalGamesPlayed = newGamesPlayed,
                highestUnlockedLevel = newHighestUnlocked,
                levelStars = updatedStars,
                milestoneHistory = newHistory
            )
        )
    }

    private fun parseIntMap(jsonStr: String): Map<Int, Int> {
        val result = mutableMapOf<Int, Int>()
        runCatching {
            val obj = JSONObject(jsonStr)
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val keyInt = k.toIntOrNull()
                if (keyInt != null) {
                    result[keyInt] = obj.optInt(k, 0)
                }
            }
        }
        return result
    }

    private fun serializeIntMap(map: Map<Int, Int>): String {
        val obj = JSONObject()
        map.forEach { (k, v) -> obj.put(k.toString(), v) }
        return obj.toString()
    }

    companion object {
        private const val PREFS_NAME = "neon_bounce_kholid_prefs"
        private const val KEY_MUSIC = "music_enabled"
        private const val KEY_SOUND = "sound_enabled"
        private const val KEY_VIBRATION = "vibration_enabled"
        private const val KEY_QUALITY = "graphics_quality"
        private const val KEY_FPS = "target_fps"
        private const val KEY_LANGUAGE = "language"
        private const val KEY_SELECTED_THEME = "selected_theme"
        private const val KEY_SHARDS = "shards"
        private const val KEY_BEST_CLASSIC = "best_classic"
        private const val KEY_BEST_ENDLESS = "best_endless"
        private const val KEY_HIGHEST_MILESTONE = "highest_milestone"
        private const val KEY_TOTAL_BOUNCES = "total_bounces"
        private const val KEY_GAMES_PLAYED = "games_played"
        private const val KEY_HIGHEST_LEVEL = "highest_level"
        private const val KEY_LEVEL_STARS = "level_stars"
        private const val KEY_UNLOCKED_BALLS = "unlocked_balls"
        private const val KEY_UNLOCKED_TRAILS = "unlocked_trails"
        private const val KEY_UNLOCKED_THEMES = "unlocked_themes"
        private const val KEY_EQUIPPED_BALL = "equipped_ball"
        private const val KEY_EQUIPPED_TRAIL = "equipped_trail"
        private const val KEY_DAILY_STREAK = "daily_streak"
        private const val KEY_LAST_DAILY_DAY = "last_daily_day"
        private const val KEY_MILESTONE_HISTORY = "milestone_history"
    }
}
