package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

class NeonAudioEngine(context: Context) {

    private val appContext = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(10)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    @Volatile private var soundEnabled = true
    @Volatile private var musicEnabled = true
    @Volatile private var vibrationEnabled = true
    @Volatile private var isForeground = true

    private var wallBounceId = 0
    private var waveBounceId = 0
    private var milestoneUpId = 0
    private var newRecordId = 0
    private var burstId = 0
    private var levelWinId = 0
    private var gameOverId = 0
    private var uiClickId = 0
    @Volatile private var soundsReady = false

    private var musicJob: Job? = null
    private var musicTrack: AudioTrack? = null

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val manager = appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        manager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        appContext.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    init {
        scope.launch {
            prepareSynthSounds()
        }
    }

    private fun prepareSynthSounds() {
        runCatching {
            val sfxDir = File(appContext.cacheDir, "neon_sfx").apply { mkdirs() }

            val wallFile = File(sfxDir, "wall.wav")
            val waveFile = File(sfxDir, "wave.wav")
            val milestoneFile = File(sfxDir, "milestone.wav")
            val recordFile = File(sfxDir, "record.wav")
            val burstFile = File(sfxDir, "burst.wav")
            val winFile = File(sfxDir, "win.wav")
            val overFile = File(sfxDir, "over.wav")
            val clickFile = File(sfxDir, "click.wav")

            if (!wallFile.exists()) writeWav(wallFile, synthTone(durationSec = 0.11f, fStart = 310f, fEnd = 140f, harmonics = 1.5f, decay = 22f, amp = 0.55f))
            if (!waveFile.exists()) writeWav(waveFile, synthPluck(durationSec = 0.16f, baseFreq = 440f, amp = 0.65f))
            if (!milestoneFile.exists()) writeWav(milestoneFile, synthChord(durationSec = 0.38f, freqs = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.5f), amp = 0.5f))
            if (!recordFile.exists()) writeWav(recordFile, synthArpeggio(durationSec = 0.56f, freqs = floatArrayOf(523.25f, 659.25f, 783.99f, 1046.5f, 1318.5f), amp = 0.55f))
            if (!burstFile.exists()) writeWav(burstFile, synthTone(durationSec = 0.24f, fStart = 680f, fEnd = 90f, harmonics = 2.0f, decay = 12f, amp = 0.65f))
            if (!winFile.exists()) writeWav(winFile, synthArpeggio(durationSec = 0.62f, freqs = floatArrayOf(440f, 554.37f, 659.25f, 880f, 1108.73f), amp = 0.55f))
            if (!overFile.exists()) writeWav(overFile, synthTone(durationSec = 0.45f, fStart = 280f, fEnd = 65f, harmonics = 1.5f, decay = 6f, amp = 0.6f))
            if (!clickFile.exists()) writeWav(clickFile, synthTone(durationSec = 0.045f, fStart = 920f, fEnd = 620f, harmonics = 0f, decay = 55f, amp = 0.38f))

            wallBounceId = soundPool.load(wallFile.absolutePath, 1)
            waveBounceId = soundPool.load(waveFile.absolutePath, 1)
            milestoneUpId = soundPool.load(milestoneFile.absolutePath, 1)
            newRecordId = soundPool.load(recordFile.absolutePath, 1)
            burstId = soundPool.load(burstFile.absolutePath, 1)
            levelWinId = soundPool.load(winFile.absolutePath, 1)
            gameOverId = soundPool.load(overFile.absolutePath, 1)
            uiClickId = soundPool.load(clickFile.absolutePath, 1)
            soundsReady = true
        }
    }

    fun applySettings(music: Boolean, sound: Boolean, vibration: Boolean) {
        val musicChanged = musicEnabled != music
        musicEnabled = music
        soundEnabled = sound
        vibrationEnabled = vibration
        if (musicChanged) {
            if (musicEnabled && isForeground) {
                startMusicLoop()
            } else {
                stopMusicLoop()
            }
        }
    }

    fun onResume() {
        isForeground = true
        if (musicEnabled) {
            startMusicLoop()
        }
    }

    fun onPause() {
        isForeground = false
        stopMusicLoop()
    }

    fun playWallBounce(intensity: Float = 1f) {
        if (!soundEnabled || !soundsReady || wallBounceId == 0) return
        val rate = (0.9f + intensity * 0.28f).coerceIn(0.75f, 1.5f)
        soundPool.play(wallBounceId, 0.45f, 0.45f, 1, 0, rate)
    }

    fun playWaveBounce(combo: Int = 1) {
        if (!soundEnabled || !soundsReady || waveBounceId == 0) return
        val semitoneStep = (combo % 12).toFloat()
        val rate = (0.88f + semitoneStep * 0.055f).coerceIn(0.8f, 1.65f)
        soundPool.play(waveBounceId, 0.72f, 0.72f, 1, 0, rate)
    }

    fun playMilestoneUp(tierIndex: Int = 1) {
        if (!soundEnabled || !soundsReady || milestoneUpId == 0) return
        val rate = (0.94f + (tierIndex % 6) * 0.06f).coerceIn(0.85f, 1.35f)
        soundPool.play(milestoneUpId, 0.85f, 0.85f, 2, 0, rate)
    }

    fun playNewRecord() {
        if (!soundEnabled || !soundsReady || newRecordId == 0) return
        soundPool.play(newRecordId, 0.95f, 0.95f, 3, 0, 1.0f)
    }

    fun playBurst() {
        if (!soundEnabled || !soundsReady || burstId == 0) return
        soundPool.play(burstId, 0.8f, 0.8f, 2, 0, 1.0f)
    }

    fun playLevelWin() {
        if (!soundEnabled || !soundsReady || levelWinId == 0) return
        soundPool.play(levelWinId, 0.9f, 0.9f, 3, 0, 1.0f)
    }

    fun playGameOver() {
        if (!soundEnabled || !soundsReady || gameOverId == 0) return
        soundPool.play(gameOverId, 0.78f, 0.78f, 2, 0, 1.0f)
    }

    fun playUiClick() {
        if (!soundEnabled || !soundsReady || uiClickId == 0) return
        soundPool.play(uiClickId, 0.45f, 0.45f, 0, 0, 1.0f)
    }

    fun vibrateLight() {
        if (!vibrationEnabled) return
        vibrateMs(12L, 90)
    }

    fun vibrateStrong() {
        if (!vibrationEnabled) return
        vibrateMs(28L, 190)
    }

    private fun vibrateMs(ms: Long, amplitude: Int) {
        val vib = vibrator ?: return
        if (!vib.hasVibrator()) return
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createOneShot(ms, amplitude))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(ms)
            }
        }
    }

    private fun startMusicLoop() {
        if (musicJob?.isActive == true) return
        musicJob = scope.launch {
            runCatching {
                val sampleRate = 22050
                val loopSeconds = 4
                val numSamples = sampleRate * loopSeconds
                val buffer = ShortArray(numSamples)
                // Ambient dark synthwave drone + pulsing fifths (A2 + E3 + B3 shimmer)
                for (i in 0 until numSamples) {
                    val t = i.toFloat() / sampleRate
                    val pulse = 0.65f + 0.35f * sin(2f * PI.toFloat() * 0.5f * t)
                    val s1 = sin(2f * PI.toFloat() * 110f * t) * 0.34f
                    val s2 = sin(2f * PI.toFloat() * 164.81f * t) * 0.24f * pulse
                    val s3 = sin(2f * PI.toFloat() * 220f * t) * 0.16f
                    val s4 = sin(2f * PI.toFloat() * 246.94f * t) * 0.10f * (0.5f + 0.5f * sin(2f * PI.toFloat() * 0.25f * t))
                    val raw = (s1 + s2 + s3 + s4) * 0.24f
                    buffer[i] = (raw.coerceIn(-1f, 1f) * Short.MAX_VALUE).toInt().toShort()
                }

                val minBuf = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(4096)

                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(sampleRate)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .setBufferSizeInBytes(minBuf)
                    .build()

                musicTrack = track
                track.play()

                var offset = 0
                val chunkSize = 1024
                while (isActive && musicEnabled && isForeground) {
                    val toWrite = minOf(chunkSize, buffer.size - offset)
                    track.write(buffer, offset, toWrite)
                    offset += toWrite
                    if (offset >= buffer.size) offset = 0
                }
            }
        }
    }

    private fun stopMusicLoop() {
        musicJob?.cancel()
        musicJob = null
        runCatching {
            musicTrack?.pause()
            musicTrack?.flush()
            musicTrack?.release()
        }
        musicTrack = null
    }

    fun release() {
        stopMusicLoop()
        soundPool.release()
        scope.cancel()
    }

    private fun synthTone(
        durationSec: Float,
        fStart: Float,
        fEnd: Float,
        harmonics: Float,
        decay: Float,
        amp: Float
    ): ShortArray {
        val sr = 44100
        val count = (sr * durationSec).toInt()
        val out = ShortArray(count)
        var phase = 0f
        var hPhase = 0f
        for (i in 0 until count) {
            val t = i.toFloat() / sr
            val progress = t / durationSec
            val freq = fStart + (fEnd - fStart) * progress
            phase += 2f * PI.toFloat() * freq / sr
            hPhase += 2f * PI.toFloat() * (freq * harmonics) / sr
            val env = exp(-decay * t) * (1f - progress)
            val sample = (sin(phase) + if (harmonics > 0f) 0.35f * sin(hPhase) else 0f) * env * amp
            out[i] = (sample.coerceIn(-1f, 1f) * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }

    private fun synthPluck(durationSec: Float, baseFreq: Float, amp: Float): ShortArray {
        val sr = 44100
        val count = (sr * durationSec).toInt()
        val out = ShortArray(count)
        for (i in 0 until count) {
            val t = i.toFloat() / sr
            val env = exp(-18f * t)
            val s = sin(2f * PI.toFloat() * baseFreq * t) +
                0.45f * sin(2f * PI.toFloat() * (baseFreq * 2f) * t) * exp(-28f * t) +
                0.2f * sin(2f * PI.toFloat() * (baseFreq * 3f) * t) * exp(-40f * t)
            out[i] = ((s * env * amp).coerceIn(-1f, 1f) * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }

    private fun synthChord(durationSec: Float, freqs: FloatArray, amp: Float): ShortArray {
        val sr = 44100
        val count = (sr * durationSec).toInt()
        val out = ShortArray(count)
        for (i in 0 until count) {
            val t = i.toFloat() / sr
            val env = exp(-7.5f * t) * (1f - (t / durationSec) * 0.4f)
            var sum = 0f
            for (f in freqs) {
                sum += sin(2f * PI.toFloat() * f * t)
            }
            val s = (sum / freqs.size) * env * amp
            out[i] = (s.coerceIn(-1f, 1f) * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }

    private fun synthArpeggio(durationSec: Float, freqs: FloatArray, amp: Float): ShortArray {
        val sr = 44100
        val count = (sr * durationSec).toInt()
        val out = ShortArray(count)
        val stepDur = durationSec / freqs.size
        for (i in 0 until count) {
            val t = i.toFloat() / sr
            var sum = 0f
            for (idx in freqs.indices) {
                val startT = idx * stepDur * 0.72f
                if (t >= startT) {
                    val localT = t - startT
                    val env = exp(-8f * localT)
                    sum += sin(2f * PI.toFloat() * freqs[idx] * localT) * env
                }
            }
            val s = (sum / 2.2f) * amp
            out[i] = (s.coerceIn(-1f, 1f) * Short.MAX_VALUE).toInt().toShort()
        }
        return out
    }

    private fun writeWav(file: File, samples: ShortArray) {
        val sampleRate = 44100
        val byteDataSize = samples.size * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray())
        header.putInt(36 + byteDataSize)
        header.put("WAVE".toByteArray())
        header.put("fmt ".toByteArray())
        header.putInt(16)
        header.putShort(1) // PCM
        header.putShort(1) // Mono
        header.putInt(sampleRate)
        header.putInt(sampleRate * 2)
        header.putShort(2)
        header.putShort(16)
        header.put("data".toByteArray())
        header.putInt(byteDataSize)

        val pcmBuffer = ByteBuffer.allocate(byteDataSize).order(ByteOrder.LITTLE_ENDIAN)
        for (s in samples) {
            pcmBuffer.putShort(s)
        }

        FileOutputStream(file).use { fos ->
            fos.write(header.array())
            fos.write(pcmBuffer.array())
        }
    }
}
