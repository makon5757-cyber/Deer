# NEON BOUNCE

**Developer:** Kholid Company  
**Repository:** `makon5757-cyber/Neon`

[![Android CI & Release](https://github.com/makon5757-cyber/Neon/actions/workflows/android.yml/badge.svg)](https://github.com/makon5757-cyber/Neon/actions/workflows/android.yml)

---

## Direct APK Download

Download the latest automatically built Debug APK directly from GitHub Releases:

- **Direct APK Link:** [NeonBounce-debug.apk](https://github.com/makon5757-cyber/Neon/releases/latest/download/NeonBounce-debug.apk)
- **All Releases:** [GitHub Releases](https://github.com/makon5757-cyber/Neon/releases)
- **Workflow Artifacts:** [GitHub Actions](https://github.com/makon5757-cyber/Neon/actions)

---

## Automated Build & Release Pipeline

Every push to `main` / `master`, tag push (`v*`), or manual trigger in [GitHub Actions](https://github.com/makon5757-cyber/Neon/actions) automatically:

1. Sets up JDK 17, Android SDK, and Gradle `9.3.1`
2. Generates a debug signing keystore if missing
3. Runs unit tests (`:app:testDebugUnitTest`)
4. Builds the Debug APK (`:app:assembleDebug`)
5. Uploads `NeonBounce-debug.apk` as a **GitHub Actions** artifact (`neon-bounce-debug-apk`)
6. Publishes `NeonBounce-debug.apk` to **GitHub Releases** (`latest-debug` or the pushed tag) for direct installation on Android devices
